<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class WP_BiTi_Cache_PRO_I18n {
    public static function init(): void {
        add_filter( 'plugin_locale', array( __CLASS__, 'filter_plugin_locale' ), 10, 2 );
        add_action( 'plugins_loaded', array( __CLASS__, 'load_textdomain' ), 1 );
    }

    public static function filter_plugin_locale( string $locale, string $domain ): string {
        if ( 'wp-biti-cache-pro' !== $domain ) {
            return $locale;
        }

        return wp_biti_cache_get_effective_locale();
    }

    public static function load_textdomain(): void {
        unload_textdomain( 'wp-biti-cache-pro' );

        $locale   = wp_biti_cache_get_effective_locale();
        $mofile   = WP_LANG_DIR . '/plugins/wp-biti-cache-pro-' . $locale . '.mo';
        $fallback = WP_BITI_CACHE_PRO_PATH . 'languages/wp-biti-cache-pro-' . $locale . '.mo';

        if ( file_exists( $mofile ) ) {
            load_textdomain( 'wp-biti-cache-pro', $mofile );
            return;
        }

        if ( file_exists( $fallback ) ) {
            load_textdomain( 'wp-biti-cache-pro', $fallback );
        }
    }
}
