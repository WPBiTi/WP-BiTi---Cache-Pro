<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class WP_BiTi_Cache_PRO_Admin_Assets {
    public static function init(): void {
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
    }

    public static function enqueue( string $hook ): void {
        if ( false === strpos( $hook, 'wp-biti' ) ) {
            return;
        }

        wp_enqueue_style( 'wp-biti-cache-admin', WP_BITI_CACHE_PRO_URL . 'assets/css/admin.css', array(), WP_BITI_CACHE_PRO_VERSION );
        wp_enqueue_script( 'wp-biti-cache-admin', WP_BITI_CACHE_PRO_URL . 'assets/js/admin.js', array(), WP_BITI_CACHE_PRO_VERSION, true );
    }
}
