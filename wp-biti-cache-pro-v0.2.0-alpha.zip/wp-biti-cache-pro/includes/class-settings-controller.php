<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class WP_BiTi_Cache_PRO_Settings_Controller {
    public static function init(): void {
        add_action( 'admin_post_wp_biti_cache_save_settings', array( __CLASS__, 'handle_save' ) );
    }

    public static function handle_save(): void {
        if ( ! WP_BiTi_Cache_PRO_Permissions::user_can_manage() ) {
            wp_die( esc_html__( 'Access denied.', 'wp-biti-cache-pro' ) );
        }

        check_admin_referer( 'wp_biti_cache_save_settings' );

        $tab   = isset( $_POST['current_tab'] ) ? sanitize_key( wp_unslash( $_POST['current_tab'] ) ) : 'overview';
        $input = isset( $_POST['wp_biti_cache_settings'] ) && is_array( $_POST['wp_biti_cache_settings'] )
            ? wp_unslash( $_POST['wp_biti_cache_settings'] )
            : array();

        $existing = wp_biti_cache_get_settings();
        $settings = WP_BiTi_Cache_PRO_Settings_Schema::sanitize_subset( $tab, $input, $existing );

        update_option( WP_BITI_CACHE_PRO_OPTION_KEY, $settings, false );

        WP_BiTi_Cache_PRO_Cache_Engine::ensure_cache_directories();
        WP_BiTi_Cache_PRO_Preload_Manager::after_settings_save( $existing, $settings );
        WP_BiTi_Cache_PRO_I18n::load_textdomain();

        $redirect = add_query_arg(
            array(
                'page'             => WP_BITI_CACHE_PRO_SLUG,
                'tab'              => $tab,
                'settings-updated' => '1',
            ),
            admin_url( 'admin.php' )
        );

        wp_safe_redirect( $redirect );
        exit;
    }
}
