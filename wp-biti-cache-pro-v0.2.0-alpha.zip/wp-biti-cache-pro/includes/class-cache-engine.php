<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class WP_BiTi_Cache_PRO_Cache_Engine {
    public static function init(): void {
        add_action( 'template_redirect', array( __CLASS__, 'maybe_start' ), 0 );
        add_action( 'save_post', array( __CLASS__, 'handle_save_post' ), 20, 3 );
        add_action( 'deleted_post', array( __CLASS__, 'handle_delete_post' ) );
        add_action( 'trashed_post', array( __CLASS__, 'handle_delete_post' ) );
        add_action( 'comment_post', array( __CLASS__, 'handle_comment_change' ) );
        add_action( 'wp_set_comment_status', array( __CLASS__, 'handle_comment_change' ) );
        add_action( 'transition_comment_status', array( __CLASS__, 'handle_transition_comment_status' ), 10, 3 );
        add_action( 'admin_post_wp_biti_cache_clear_all', array( __CLASS__, 'handle_admin_clear_all' ) );
        add_action( 'admin_post_wp_biti_cache_clear_all_and_minified', array( __CLASS__, 'handle_admin_clear_all_and_minified' ) );
        add_action( 'admin_post_wp_biti_cache_regenerate_rules', array( __CLASS__, 'handle_regenerate_rules' ) );
    }

    public static function ensure_cache_directories(): void {
        $filesystem = wp_biti_cache_filesystem();
        if ( ! $filesystem ) {
            return;
        }

        foreach ( array( WP_CONTENT_DIR . '/cache', WP_BITI_CACHE_PRO_CACHE_DIR, WP_BITI_CACHE_PRO_MINIFIED_DIR ) as $directory ) {
            if ( ! $filesystem->exists( $directory ) ) {
                $filesystem->mkdir( $directory, FS_CHMOD_DIR );
            }
            if ( $filesystem->exists( $directory ) ) {
                $index_file = trailingslashit( $directory ) . 'index.html';
                if ( ! $filesystem->exists( $index_file ) ) {
                    $filesystem->put_contents( $index_file, '', FS_CHMOD_FILE );
                }
            }
        }
    }

    public static function maybe_start(): void {
        if ( ! self::is_cache_enabled() || ! self::is_request_cacheable() ) {
            return;
        }

        self::ensure_cache_directories();
        $cache_file = self::get_cache_file_path();
        if ( self::is_cache_fresh( $cache_file ) ) {
            $content = self::read_file( $cache_file );
            if ( is_string( $content ) && '' !== $content ) {
                self::emit_headers( true );
                self::output_content( $content );
                exit;
            }
        }

        ob_start( array( __CLASS__, 'buffer_callback' ) );
    }

    public static function buffer_callback( string $html ): string {
        if ( ! self::is_request_cacheable() ) {
            return $html;
        }

        $response_code = function_exists( 'http_response_code' ) ? (int) http_response_code() : 200;
        if ( 200 !== $response_code ) {
            return $html;
        }

        $html = WP_BiTi_Cache_PRO_Optimization::optimize_frontend_html( $html );

        $cache_file = self::get_cache_file_path();
        self::write_file( $cache_file, $html );
        wp_biti_cache_update_state( array( 'last_cache_write' => time() ) );
        self::emit_headers( false );

        return $html;
    }

    public static function handle_admin_clear_all(): void {
        if ( ! WP_BiTi_Cache_PRO_Permissions::user_can_manage() ) {
            wp_die( esc_html__( 'Access denied.', 'wp-biti-cache-pro' ) );
        }

        check_admin_referer( 'wp_biti_cache_clear_all' );
        self::clear_page_cache();
        WP_BiTi_Cache_PRO_Preload_Manager::maybe_restart_after_purge();
        self::redirect_to_admin( 'tools', 'cache-reset' );
    }

    public static function handle_admin_clear_all_and_minified(): void {
        if ( ! WP_BiTi_Cache_PRO_Permissions::user_can_manage() ) {
            wp_die( esc_html__( 'Access denied.', 'wp-biti-cache-pro' ) );
        }

        check_admin_referer( 'wp_biti_cache_clear_all_and_minified' );
        self::clear_page_cache();
        self::clear_minified_assets();
        WP_BiTi_Cache_PRO_Preload_Manager::maybe_restart_after_purge();
        self::redirect_to_admin( 'tools', 'minified-reset' );
    }

    public static function handle_regenerate_rules(): void {
        if ( ! WP_BiTi_Cache_PRO_Permissions::user_can_manage() ) {
            wp_die( esc_html__( 'Access denied.', 'wp-biti-cache-pro' ) );
        }

        check_admin_referer( 'wp_biti_cache_regenerate_rules' );
        self::ensure_cache_directories();
        wp_biti_cache_update_state( array( 'last_rules_regenerate' => time() ) );
        self::redirect_to_admin( 'tools', 'rules-regenerated' );
    }

    public static function clear_page_cache(): void {
        self::ensure_cache_directories();
        self::delete_directory_contents( WP_BITI_CACHE_PRO_CACHE_DIR );
        wp_biti_cache_update_state( array( 'last_purge' => time() ) );
    }

    public static function clear_minified_assets(): void {
        self::ensure_cache_directories();
        self::delete_directory_contents( WP_BITI_CACHE_PRO_MINIFIED_DIR );
        wp_biti_cache_update_state( array( 'last_minified_purge' => time() ) );
    }

    public static function clear_all_cache(): void {
        self::clear_page_cache();
    }

    public static function handle_save_post( int $post_id, WP_Post $post, bool $update ): void {
        if ( wp_is_post_revision( $post_id ) || 'publish' !== $post->post_status ) {
            return;
        }

        if ( $update && '1' !== (string) wp_biti_cache_get_setting( 'auto_purge_on_update_content', '1' ) ) {
            return;
        }

        if ( ! $update && '1' !== (string) wp_biti_cache_get_setting( 'auto_purge_on_new_content', '1' ) ) {
            return;
        }

        self::clear_page_cache();
        WP_BiTi_Cache_PRO_Preload_Manager::maybe_restart_after_purge();
    }

    public static function handle_delete_post( int $post_id ): void {
        if ( $post_id > 0 ) {
            self::clear_page_cache();
            WP_BiTi_Cache_PRO_Preload_Manager::maybe_restart_after_purge();
        }
    }

    public static function handle_comment_change(): void {
        self::clear_page_cache();
        WP_BiTi_Cache_PRO_Preload_Manager::maybe_restart_after_purge();
    }

    public static function handle_transition_comment_status( string $new_status, string $old_status, WP_Comment $comment ): void {
        if ( $new_status !== $old_status && $comment->comment_post_ID ) {
            self::clear_page_cache();
            WP_BiTi_Cache_PRO_Preload_Manager::maybe_restart_after_purge();
        }
    }

    public static function is_cache_enabled(): bool {
        return '1' === (string) wp_biti_cache_get_setting( 'enable_cache', '0' );
    }

    private static function is_request_cacheable(): bool {
        if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
            return false;
        }

        if ( function_exists( 'is_user_logged_in' ) && is_user_logged_in() && '1' !== (string) wp_biti_cache_get_setting( 'cache_logged_in', '0' ) ) {
            return false;
        }

        $request_method = isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) ) : 'GET';
        if ( ! in_array( $request_method, array( 'GET', 'HEAD' ), true ) ) {
            return false;
        }

        if ( function_exists( 'is_feed' ) && is_feed() ) {
            return false;
        }

        if ( function_exists( 'is_preview' ) && is_preview() ) {
            return false;
        }

        if ( function_exists( 'is_trackback' ) && is_trackback() ) {
            return false;
        }

        if ( function_exists( 'is_search' ) && is_search() ) {
            return false;
        }

        if ( function_exists( 'is_404' ) && is_404() ) {
            return false;
        }

        if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
            return false;
        }

        if ( isset( $_GET['preview'] ) || isset( $_GET['customize_changeset_uuid'] ) ) {
            return false;
        }

        if ( function_exists( 'is_cart' ) && is_cart() ) {
            return false;
        }

        if ( function_exists( 'is_checkout' ) && is_checkout() ) {
            return false;
        }

        if ( function_exists( 'is_account_page' ) && is_account_page() ) {
            return false;
        }

        if ( self::matches_excluded_path() || self::matches_excluded_cookie() || self::matches_excluded_user_agent() ) {
            return false;
        }

        if ( ! self::is_query_cacheable() ) {
            return false;
        }

        if ( wp_biti_cache_is_mobile_request() && '1' !== (string) wp_biti_cache_get_setting( 'cache_mobile', '1' ) ) {
            return false;
        }

        return true;
    }

    private static function is_query_cacheable(): bool {
        if ( empty( $_GET ) ) {
            return true;
        }

        $allowed = array( 'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'gclid', 'fbclid', 'msclkid' );
        foreach ( array_keys( wp_unslash( $_GET ) ) as $query_key ) {
            if ( ! in_array( sanitize_key( (string) $query_key ), $allowed, true ) ) {
                return false;
            }
        }

        return true;
    }

    private static function matches_excluded_path(): bool {
        $path       = self::current_request_path();
        $configured = wp_biti_cache_parse_multiline_list( (string) wp_biti_cache_get_setting( 'excluded_paths', '' ) );
        foreach ( $configured as $exclude ) {
            if ( '' !== $exclude && false !== strpos( $path, $exclude ) ) {
                return true;
            }
        }

        return false;
    }

    private static function matches_excluded_cookie(): bool {
        $configured = wp_biti_cache_parse_multiline_list( (string) wp_biti_cache_get_setting( 'excluded_cookies', '' ) );
        foreach ( $configured as $cookie_name ) {
            if ( isset( $_COOKIE[ $cookie_name ] ) ) {
                return true;
            }
        }

        return false;
    }

    private static function matches_excluded_user_agent(): bool {
        $agent      = isset( $_SERVER['HTTP_USER_AGENT'] ) ? strtolower( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) ) : '';
        $configured = wp_biti_cache_parse_multiline_list( (string) wp_biti_cache_get_setting( 'excluded_user_agents', '' ) );
        foreach ( $configured as $item ) {
            if ( '' !== $item && false !== strpos( $agent, strtolower( $item ) ) ) {
                return true;
            }
        }

        return false;
    }

    private static function current_request_path(): string {
        $request_uri = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '/';
        $path        = wp_parse_url( $request_uri, PHP_URL_PATH );

        return is_string( $path ) ? $path : '/';
    }

    private static function get_cache_file_path(): string {
        $path = self::current_request_path();
        if ( '' === $path ) {
            $path = '/';
        }
        $path = user_trailingslashit( $path );
        $key  = md5( home_url( $path ) . '|' . ( wp_biti_cache_is_mobile_request() ? 'mobile' : 'desktop' ) );

        return WP_BITI_CACHE_PRO_CACHE_DIR . $key . '.html';
    }

    private static function is_cache_fresh( string $cache_file ): bool {
        if ( ! file_exists( $cache_file ) ) {
            return false;
        }

        $ttl = (int) wp_biti_cache_get_setting( 'cache_ttl_minutes', 1440 ) * MINUTE_IN_SECONDS;

        return ( time() - (int) filemtime( $cache_file ) ) < $ttl;
    }

    private static function emit_headers( bool $is_hit ): void {
        if ( headers_sent() ) {
            return;
        }

        header( 'X-WP-BiTi-Cache: ' . ( $is_hit ? 'HIT' : 'MISS' ) );

        if ( '1' === (string) wp_biti_cache_get_setting( 'enable_browser_cache', '1' ) ) {
            $max_age = (int) wp_biti_cache_get_setting( 'cache_ttl_minutes', 1440 ) * MINUTE_IN_SECONDS;
            header( 'Cache-Control: public, max-age=' . $max_age . ', stale-while-revalidate=60' );
        }
    }

    private static function output_content( string $content ): void {
        if ( '1' === (string) wp_biti_cache_get_setting( 'enable_gzip', '0' ) && function_exists( 'gzencode' ) ) {
            $encoding = isset( $_SERVER['HTTP_ACCEPT_ENCODING'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_ACCEPT_ENCODING'] ) ) : '';
            if ( false !== strpos( $encoding, 'gzip' ) ) {
                header( 'Content-Encoding: gzip' );
                header( 'Vary: Accept-Encoding' );
                // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Cached frontend payload.
                echo gzencode( $content, 6 );
                return;
            }
        }

        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Cached frontend payload.
        echo $content;
    }

    private static function read_file( string $path ): string {
        $filesystem = wp_biti_cache_filesystem();
        if ( ! $filesystem || ! $filesystem->exists( $path ) ) {
            return '';
        }

        $contents = $filesystem->get_contents( $path );
        return is_string( $contents ) ? $contents : '';
    }

    private static function write_file( string $path, string $content ): void {
        $filesystem = wp_biti_cache_filesystem();
        if ( ! $filesystem ) {
            return;
        }

        $directory = dirname( $path );
        if ( ! $filesystem->exists( $directory ) ) {
            $filesystem->mkdir( $directory, FS_CHMOD_DIR );
        }
        $filesystem->put_contents( $path, $content, FS_CHMOD_FILE );
    }

    private static function delete_directory_contents( string $directory ): void {
        $filesystem = wp_biti_cache_filesystem();
        if ( ! $filesystem || ! $filesystem->exists( $directory ) ) {
            return;
        }

        $items = $filesystem->dirlist( $directory, false, true );
        if ( ! is_array( $items ) ) {
            return;
        }

        foreach ( $items as $item_name => $item_data ) {
            if ( 'index.html' === $item_name ) {
                continue;
            }

            $item_path = trailingslashit( $directory ) . $item_name;
            if ( 'd' === ( $item_data['type'] ?? '' ) ) {
                self::delete_directory_contents( $item_path );
                $filesystem->rmdir( $item_path, true );
            } else {
                $filesystem->delete( $item_path, false, 'f' );
            }
        }
    }

    private static function redirect_to_admin( string $tab, string $flag ): void {
        $redirect = add_query_arg(
            array(
                'page' => WP_BITI_CACHE_PRO_SLUG,
                'tab'  => $tab,
                $flag  => '1',
            ),
            admin_url( 'admin.php' )
        );
        wp_safe_redirect( $redirect );
        exit;
    }
}
