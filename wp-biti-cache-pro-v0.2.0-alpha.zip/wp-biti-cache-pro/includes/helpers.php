<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function wp_biti_cache_get_settings(): array {
    $settings = get_option( WP_BITI_CACHE_PRO_OPTION_KEY, array() );
    if ( ! is_array( $settings ) ) {
        $settings = array();
    }

    return wp_parse_args( $settings, WP_BiTi_Cache_PRO_Settings_Schema::defaults() );
}

function wp_biti_cache_get_setting( string $key, $default = null ) {
    $settings = wp_biti_cache_get_settings();

    return array_key_exists( $key, $settings ) ? $settings[ $key ] : $default;
}

function wp_biti_cache_get_state(): array {
    $state = get_option( WP_BITI_CACHE_PRO_STATE_OPTION, array() );
    if ( ! is_array( $state ) ) {
        $state = array();
    }

    return wp_parse_args(
        $state,
        array(
            'last_purge'           => 0,
            'last_minified_purge'  => 0,
            'last_cache_write'     => 0,
            'preload_status'       => 'idle',
            'preload_total'        => 0,
            'preload_processed'    => 0,
            'preload_last_run'     => 0,
            'last_db_cleanup'      => 0,
            'last_db_cleanup_log'  => array(),
            'last_rules_regenerate'=> 0,
        )
    );
}

function wp_biti_cache_update_state( array $data ): void {
    update_option( WP_BITI_CACHE_PRO_STATE_OPTION, wp_parse_args( $data, wp_biti_cache_get_state() ), false );
}

function wp_biti_cache_is_mobile_request(): bool {
    if ( isset( $_SERVER['HTTP_SEC_CH_UA_MOBILE'] ) ) {
        return '?1' === (string) wp_unslash( $_SERVER['HTTP_SEC_CH_UA_MOBILE'] );
    }

    if ( function_exists( 'wp_is_mobile' ) ) {
        return wp_is_mobile();
    }

    return false;
}

function wp_biti_cache_parse_multiline_list( string $value ): array {
    $lines = preg_split( '/\r\n|\r|\n/', $value );
    $lines = array_map( 'trim', (array) $lines );
    $lines = array_filter( $lines, 'strlen' );

    return array_values( array_unique( $lines ) );
}

function wp_biti_cache_format_datetime( int $timestamp ): string {
    if ( $timestamp <= 0 ) {
        return __( 'Never', 'wp-biti-cache-pro' );
    }

    return wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $timestamp );
}

function wp_biti_cache_filesystem() {
    require_once ABSPATH . 'wp-admin/includes/file.php';
    WP_Filesystem();
    global $wp_filesystem;

    return $wp_filesystem;
}

function wp_biti_cache_get_available_languages(): array {
    return array(
        'en_US' => 'English',
        'it_IT' => 'Italiano',
        'de_DE' => 'Deutsch',
        'es_ES' => 'Español',
        'fr_FR' => 'Français',
        'ru_RU' => 'Русский',
    );
}

function wp_biti_cache_get_wordpress_locale(): string {
    if ( function_exists( 'determine_locale' ) ) {
        $locale = determine_locale();
    } else {
        $locale = get_locale();
    }

    return is_string( $locale ) && '' !== $locale ? $locale : 'en_US';
}

function wp_biti_cache_get_effective_locale(): string {
    $mode   = (string) wp_biti_cache_get_setting( 'plugin_language_mode', 'wordpress' );
    $manual = (string) wp_biti_cache_get_setting( 'plugin_language', 'en_US' );
    $langs  = wp_biti_cache_get_available_languages();

    if ( 'manual' === $mode && isset( $langs[ $manual ] ) ) {
        return $manual;
    }

    $wp_locale = wp_biti_cache_get_wordpress_locale();
    if ( isset( $langs[ $wp_locale ] ) ) {
        return $wp_locale;
    }

    $wp_prefix = substr( $wp_locale, 0, 2 );
    foreach ( array_keys( $langs ) as $lang_locale ) {
        if ( $wp_prefix === substr( $lang_locale, 0, 2 ) ) {
            return $lang_locale;
        }
    }

    return 'en_US';
}

function wp_biti_cache_get_effective_language_label(): string {
    $langs  = wp_biti_cache_get_available_languages();
    $locale = wp_biti_cache_get_effective_locale();

    return $langs[ $locale ] ?? 'English';
}
