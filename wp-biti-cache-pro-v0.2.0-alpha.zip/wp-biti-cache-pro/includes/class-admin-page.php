<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class WP_BiTi_Cache_PRO_Admin_Page {
    public static function init(): void {
        add_action( 'wp_biti_register_plugin_pages', array( __CLASS__, 'register_page' ) );
    }

    public static function register_page( WP_BiTi_Core_Plugin_Page_Registry $registry ): void {
        $registry->register_page(
            array(
                'title'      => __( 'WP BiTi Cache', 'wp-biti-cache-pro' ),
                'menu_title' => __( 'WP BiTi Cache', 'wp-biti-cache-pro' ),
                'capability' => 'wp_biti_manage',
                'slug'       => WP_BITI_CACHE_PRO_SLUG,
                'callback'   => array( __CLASS__, 'render' ),
            )
        );
    }

    public static function get_tabs(): array {
        return array(
            'overview'     => __( 'Overview', 'wp-biti-cache-pro' ),
            'cache'        => __( 'Cache', 'wp-biti-cache-pro' ),
            'preload'      => __( 'Preload', 'wp-biti-cache-pro' ),
            'optimization' => __( 'Optimization', 'wp-biti-cache-pro' ),
            'exclusions'   => __( 'Exclusions', 'wp-biti-cache-pro' ),
            'database'     => __( 'Database', 'wp-biti-cache-pro' ),
            'tools'        => __( 'Tools', 'wp-biti-cache-pro' ),
        );
    }

    public static function get_notices(): array {
        return array(
            'cache-reset'      => __( 'Cache cleared successfully.', 'wp-biti-cache-pro' ),
            'minified-reset'   => __( 'Cache and minified CSS/JS cleared successfully.', 'wp-biti-cache-pro' ),
            'preload-started'  => __( 'Preload queue created and scheduled.', 'wp-biti-cache-pro' ),
            'database-cleaned' => __( 'Database cleanup completed.', 'wp-biti-cache-pro' ),
            'rules-regenerated'=> __( 'Cache directories and runtime files were checked again.', 'wp-biti-cache-pro' ),
        );
    }

    public static function render(): void {
        if ( ! WP_BiTi_Cache_PRO_Permissions::user_can_manage() ) {
            wp_die( esc_html__( 'Access denied.', 'wp-biti-cache-pro' ) );
        }

        $tabs     = self::get_tabs();
        $raw_tab  = filter_input( INPUT_GET, 'tab', FILTER_SANITIZE_FULL_SPECIAL_CHARS );
        $tab      = is_string( $raw_tab ) ? sanitize_key( wp_unslash( $raw_tab ) ) : 'overview';
        $tab      = array_key_exists( $tab, $tabs ) ? $tab : 'overview';
        $settings = wp_biti_cache_get_settings();
        $state    = wp_biti_cache_get_state();
        $notices  = array();

        foreach ( self::get_notices() as $notice_key => $notice_message ) {
            $notice_value = filter_input( INPUT_GET, $notice_key, FILTER_SANITIZE_FULL_SPECIAL_CHARS );
            if ( is_string( $notice_value ) && '' !== $notice_value ) {
                $notices[] = $notice_message;
            }
        }

        include WP_BITI_CACHE_PRO_PATH . 'templates/admin-page.php';
    }
}
