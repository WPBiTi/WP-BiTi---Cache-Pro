<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class WP_BiTi_Cache_PRO_Permissions {
    public static function bootstrap(): void {
        add_action( 'init', array( __CLASS__, 'ensure_caps' ) );
    }

    public static function ensure_caps(): void {
        foreach ( array( 'administrator', 'shop_manager' ) as $role_name ) {
            $role = get_role( $role_name );
            if ( $role instanceof WP_Role ) {
                $role->add_cap( 'wp_biti_access' );
                $role->add_cap( 'wp_biti_manage' );
            }
        }
    }

    public static function user_can_manage(): bool {
        return is_user_logged_in() && current_user_can( 'wp_biti_manage' );
    }
}
