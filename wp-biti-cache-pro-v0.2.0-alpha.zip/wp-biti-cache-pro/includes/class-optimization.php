<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class WP_BiTi_Cache_PRO_Optimization {
    public static function init(): void {
        add_action( 'init', array( __CLASS__, 'maybe_disable_emojis' ) );
        add_filter( 'the_content', array( __CLASS__, 'maybe_lazy_load_content' ), 20 );
        add_filter( 'post_thumbnail_html', array( __CLASS__, 'add_lazy_attributes' ), 20 );
        add_filter( 'get_avatar', array( __CLASS__, 'add_lazy_attributes' ), 20 );
    }

    public static function is_html_minify_enabled(): bool {
        return '1' === (string) wp_biti_cache_get_setting( 'minify_html', '0' ) || '1' === (string) wp_biti_cache_get_setting( 'advanced_html_optimization', '0' );
    }

    public static function optimize_frontend_html( string $html ): string {
        if ( '' === trim( $html ) ) {
            return $html;
        }

        if ( '1' === (string) wp_biti_cache_get_setting( 'minify_css', '0' ) || '1' === (string) wp_biti_cache_get_setting( 'combine_css', '0' ) ) {
            $html = self::process_css_assets( $html );
        }

        if ( '1' === (string) wp_biti_cache_get_setting( 'minify_js', '0' ) || '1' === (string) wp_biti_cache_get_setting( 'combine_js', '0' ) || '1' === (string) wp_biti_cache_get_setting( 'footer_js_combine', '0' ) ) {
            $html = self::process_js_assets( $html );
        }

        if ( '1' === (string) wp_biti_cache_get_setting( 'advanced_html_optimization', '0' ) ) {
            $html = self::advanced_minify_html( $html );
        } elseif ( '1' === (string) wp_biti_cache_get_setting( 'minify_html', '0' ) ) {
            $html = self::minify_html( $html );
        }

        return $html;
    }

    public static function minify_html( string $html ): string {
        if ( '' === trim( $html ) ) {
            return $html;
        }

        $preserved = array();
        $html      = preg_replace_callback(
            '#<(pre|textarea|script|style)([^>]*)>.*?</\1>#is',
            static function ( array $matches ) use ( &$preserved ): string {
                $key               = '%%WPBITI_PRESERVE_' . count( $preserved ) . '%%';
                $preserved[ $key ] = $matches[0];
                return $key;
            },
            $html
        );

        $html = preg_replace( '/>\s+</', '> <', $html );
        $html = preg_replace( '/\s{2,}/', ' ', $html );

        return is_string( $html ) ? strtr( trim( $html ), $preserved ) : '';
    }

    public static function advanced_minify_html( string $html ): string {
        $html = self::minify_html( $html );
        $html = preg_replace( '/<!--(?!\[if).*?-->/', '', $html );
        $html = preg_replace_callback(
            '#<style([^>]*)>(.*?)</style>#is',
            static function ( array $matches ): string {
                return '<style' . $matches[1] . '>' . self::minify_css_content( $matches[2], true ) . '</style>';
            },
            $html
        );
        $html = preg_replace_callback(
            '#<script([^>]*)>(.*?)</script>#is',
            static function ( array $matches ): string {
                if ( false !== stripos( $matches[1], 'application/ld+json' ) ) {
                    return $matches[0];
                }
                return '<script' . $matches[1] . '>' . self::minify_js_content( $matches[2] ) . '</script>';
            },
            $html
        );
        $html = preg_replace( '/\s+>/', '>', $html );

        return is_string( $html ) ? trim( $html ) : '';
    }

    public static function maybe_disable_emojis(): void {
        if ( '1' !== (string) wp_biti_cache_get_setting( 'disable_emojis', '1' ) ) {
            return;
        }

        remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
        remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
        remove_action( 'wp_print_styles', 'print_emoji_styles' );
        remove_action( 'admin_print_styles', 'print_emoji_styles' );
        remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
        remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
        remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
    }

    public static function maybe_lazy_load_content( string $content ): string {
        if ( '1' !== (string) wp_biti_cache_get_setting( 'lazy_load_media', '1' ) ) {
            return $content;
        }

        return self::add_lazy_attributes( $content );
    }

    public static function add_lazy_attributes( string $markup ): string {
        if ( '1' !== (string) wp_biti_cache_get_setting( 'lazy_load_media', '1' ) ) {
            return $markup;
        }

        $markup = preg_replace( '/<img(?![^>]*loading=)([^>]*)>/i', '<img loading="lazy" decoding="async"$1>', $markup );
        $markup = preg_replace( '/<iframe(?![^>]*loading=)([^>]*)>/i', '<iframe loading="lazy"$1>', $markup );

        return is_string( $markup ) ? $markup : '';
    }

    private static function process_css_assets( string $html ): string {
        if ( false === stripos( $html, '<link' ) ) {
            return $html;
        }

        $should_combine = '1' === (string) wp_biti_cache_get_setting( 'combine_css', '0' );
        $is_advanced    = '1' === (string) wp_biti_cache_get_setting( 'advanced_css_optimization', '0' );
        $css_bundle     = array();
        $link_tags      = array();

        if ( ! preg_match_all( '#<link\b[^>]*rel=("|\")?stylesheet\1?[^>]*>#i', $html, $matches ) ) {
            return $html;
        }

        foreach ( $matches[0] as $full_tag ) {
            $href = self::extract_attribute( $full_tag, 'href' );
            if ( '' === $href || false !== stripos( $full_tag, 'data-no-optimize' ) ) {
                continue;
            }

            $asset = self::prepare_asset( $href );
            if ( ! $asset ) {
                continue;
            }

            $media = self::extract_attribute( $full_tag, 'media' );
            if ( '' !== $media && 'all' !== strtolower( $media ) ) {
                $new_url = self::write_minified_asset( 'css', $asset['path'], self::minify_css_content( $asset['content'], $is_advanced ) );
                if ( $new_url ) {
                    $html = str_replace( $href, $new_url, $html );
                }
                continue;
            }

            if ( $should_combine ) {
                $css_bundle[] = $asset['content'];
                $link_tags[]  = $full_tag;
            } else {
                $new_url = self::write_minified_asset( 'css', $asset['path'], self::minify_css_content( $asset['content'], $is_advanced ) );
                if ( $new_url ) {
                    $html = str_replace( $href, $new_url, $html );
                }
            }
        }

        if ( $should_combine && ! empty( $css_bundle ) ) {
            $combined = self::minify_css_content( implode( "\n", $css_bundle ), $is_advanced );
            $new_url  = self::write_named_asset( 'css', 'combined-head', $combined );
            if ( $new_url ) {
                $replacement = '<link rel="stylesheet" id="wp-biti-cache-combined-css" href="' . esc_url( $new_url ) . '" media="all" />';
                $html        = str_replace( $link_tags, array_fill( 0, count( $link_tags ), '' ), $html );
                if ( false !== stripos( $html, '</head>' ) ) {
                    $html = str_ireplace( '</head>', $replacement . "\n</head>", $html );
                }
            }
        }

        return $html;
    }

    private static function process_js_assets( string $html ): string {
        if ( false === stripos( $html, '<script' ) ) {
            return $html;
        }

        $combine_head   = '1' === (string) wp_biti_cache_get_setting( 'combine_js', '0' );
        $combine_footer = '1' === (string) wp_biti_cache_get_setting( 'footer_js_combine', '0' );
        $head_assets     = array();
        $head_tags       = array();
        $footer_assets   = array();
        $footer_tags     = array();

        if ( ! preg_match_all( '#<script\b[^>]*src=("|\")(.*?)\1[^>]*></script>#i', $html, $matches, PREG_SET_ORDER ) ) {
            return $html;
        }

        foreach ( $matches as $match ) {
            $full_tag = $match[0];
            $src      = $match[2];
            if ( '' === $src || false !== stripos( $full_tag, 'data-no-optimize' ) || false !== stripos( $full_tag, 'type="module"' ) || false !== stripos( $full_tag, 'type=\'module\'' ) || false !== stripos( $full_tag, 'async' ) || false !== stripos( $full_tag, 'defer' ) ) {
                continue;
            }

            $asset = self::prepare_asset( $src );
            if ( ! $asset ) {
                continue;
            }

            $position = self::is_footer_script( $html, $full_tag ) ? 'footer' : 'head';
            if ( 'head' === $position && $combine_head ) {
                $head_assets[] = $asset['content'];
                $head_tags[]   = $full_tag;
            } elseif ( 'footer' === $position && $combine_footer ) {
                $footer_assets[] = $asset['content'];
                $footer_tags[]   = $full_tag;
            } else {
                $new_url = self::write_minified_asset( 'js', $asset['path'], self::minify_js_content( $asset['content'] ) );
                if ( $new_url ) {
                    $html = str_replace( $src, $new_url, $html );
                }
            }
        }

        if ( $combine_head && ! empty( $head_assets ) ) {
            $new_url = self::write_named_asset( 'js', 'combined-head', self::minify_js_content( implode( ';', $head_assets ) ) );
            if ( $new_url ) {
                $replacement = '<script id="wp-biti-cache-combined-head-js" src="' . esc_url( $new_url ) . '"></script>';
                $html        = str_replace( $head_tags, array_fill( 0, count( $head_tags ), '' ), $html );
                if ( false !== stripos( $html, '</head>' ) ) {
                    $html = str_ireplace( '</head>', $replacement . "\n</head>", $html );
                }
            }
        }

        if ( $combine_footer && ! empty( $footer_assets ) ) {
            $new_url = self::write_named_asset( 'js', 'combined-footer', self::minify_js_content( implode( ';', $footer_assets ) ) );
            if ( $new_url ) {
                $replacement = '<script id="wp-biti-cache-combined-footer-js" src="' . esc_url( $new_url ) . '"></script>';
                $html        = str_replace( $footer_tags, array_fill( 0, count( $footer_tags ), '' ), $html );
                if ( false !== stripos( $html, '</body>' ) ) {
                    $html = str_ireplace( '</body>', $replacement . "\n</body>", $html );
                }
            }
        }

        return $html;
    }

    private static function prepare_asset( string $url ): ?array {
        $path = self::local_path_from_url( $url );
        if ( '' === $path || ! file_exists( $path ) || ! is_readable( $path ) ) {
            return null;
        }

        $content = file_get_contents( $path );
        if ( ! is_string( $content ) || '' === $content ) {
            return null;
        }

        return array(
            'path'    => $path,
            'content' => $content,
        );
    }

    private static function local_path_from_url( string $url ): string {
        $decoded = html_entity_decode( $url, ENT_QUOTES, 'UTF-8' );
        $parts   = wp_parse_url( $decoded );
        if ( ! is_array( $parts ) ) {
            return '';
        }

        $home_parts = wp_parse_url( home_url( '/' ) );
        $home_host  = is_array( $home_parts ) ? ( $home_parts['host'] ?? '' ) : '';
        $url_host   = $parts['host'] ?? $home_host;
        if ( $home_host && $url_host && strtolower( (string) $url_host ) !== strtolower( (string) $home_host ) ) {
            return '';
        }

        $path = isset( $parts['path'] ) ? (string) $parts['path'] : '';
        if ( '' === $path ) {
            return '';
        }

        $absolute = ABSPATH . ltrim( $path, '/' );
        $real     = realpath( $absolute );
        $root     = realpath( ABSPATH );
        if ( false === $real || false === $root ) {
            return '';
        }
        if ( 0 !== strpos( $real, $root ) ) {
            return '';
        }

        return $real;
    }

    private static function minify_css_content( string $content, bool $advanced = false ): string {
        $content = preg_replace( '!/\*.*?\*/!s', '', $content );
        $content = preg_replace( '/\s+/', ' ', $content );
        $content = preg_replace( '/\s*([{};:,])\s*/', '$1', $content );
        $content = str_replace( ';}', '}', $content );
        if ( $advanced ) {
            $content = preg_replace( '/(?<=[:;,{}])0(px|em|rem|%|vh|vw)/i', '0', $content );
            $content = preg_replace( '/#([0-9a-f])\1([0-9a-f])\2([0-9a-f])\3/i', '#$1$2$3', $content );
        }
        return trim( (string) $content );
    }

    private static function minify_js_content( string $content ): string {
        $preserved = array();
        $content   = preg_replace_callback(
            '#(["\"]).*?(?<!\\)\1#s',
            static function ( array $matches ) use ( &$preserved ): string {
                $key               = '%%WPBITI_JS_' . count( $preserved ) . '%%';
                $preserved[ $key ] = $matches[0];
                return $key;
            },
            $content
        );
        $content = preg_replace( '#/\*.*?\*/#s', '', $content );
        $content = preg_replace( '#(^|[^:])//.*$#m', '$1', $content );
        $content = preg_replace( '/\s+/', ' ', $content );
        $content = preg_replace( '/\s*([{}();,:=+<>\-])\s*/', '$1', $content );
        $content = strtr( trim( (string) $content ), $preserved );
        return $content;
    }

    private static function write_minified_asset( string $type, string $source_path, string $content ): string {
        $hash = md5( $source_path . '|' . WP_BITI_CACHE_PRO_VERSION . '|' . filemtime( $source_path ) . '|' . $content );
        return self::write_named_asset( $type, $hash, $content );
    }

    private static function write_named_asset( string $type, string $name, string $content ): string {
        $filesystem = wp_biti_cache_filesystem();
        if ( ! $filesystem ) {
            return '';
        }

        $directory = trailingslashit( WP_BITI_CACHE_PRO_MINIFIED_DIR ) . $type;
        if ( ! $filesystem->exists( $directory ) ) {
            $filesystem->mkdir( $directory, FS_CHMOD_DIR );
            $index_file = trailingslashit( $directory ) . 'index.html';
            if ( ! $filesystem->exists( $index_file ) ) {
                $filesystem->put_contents( $index_file, '', FS_CHMOD_FILE );
            }
        }

        $filename = sanitize_file_name( $name ) . '.' . $type;
        $path     = trailingslashit( $directory ) . $filename;
        $filesystem->put_contents( $path, $content, FS_CHMOD_FILE );

        return content_url( 'cache/wp-biti-cache/minified/' . $type . '/' . $filename );
    }

    private static function extract_attribute( string $tag, string $attribute ): string {
        $pattern = '#\b' . preg_quote( $attribute, '#' ) . '=("|\")(.*?)\1#i';
        if ( preg_match( $pattern, $tag, $matches ) ) {
            return html_entity_decode( $matches[2], ENT_QUOTES, 'UTF-8' );
        }
        return '';
    }

    private static function is_footer_script( string $html, string $tag ): bool {
        $head_close = stripos( $html, '</head>' );
        $tag_pos    = strpos( $html, $tag );
        if ( false === $tag_pos || false === $head_close ) {
            return false;
        }
        return $tag_pos > $head_close;
    }
}
