<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function wp_biti_core_version(): string {
    return WP_BiTi_Core_Runtime_Registry::get_version();
}

function wp_biti_core_is_loaded(): bool {
    return WP_BiTi_Core_Runtime_Registry::is_loaded();
}
