<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class WP_BiTi_Core_Dashboard_Page {
    public static function render(): void {
        if ( ! current_user_can( 'wp_biti_access' ) ) {
            wp_die( esc_html__( 'Access denied.', 'wp-biti-cache-pro' ) );
        }
        $boxes = WP_BiTi_Core_Dashboard_Metaboxes::boxes();
        include WP_BITI_CACHE_PRO_PATH . 'templates/core-dashboard.php';
    }
}
