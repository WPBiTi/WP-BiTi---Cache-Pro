<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class WP_BiTi_Core_Settings_Tab_Registry {
    private array $tabs = array();

    public function register_tab( array $tab ): void {
        if ( empty( $tab['slug'] ) || empty( $tab['callback'] ) ) {
            return;
        }
        $this->tabs[ $tab['slug'] ] = $tab;
    }

    public function all(): array {
        return $this->tabs;
    }
}
