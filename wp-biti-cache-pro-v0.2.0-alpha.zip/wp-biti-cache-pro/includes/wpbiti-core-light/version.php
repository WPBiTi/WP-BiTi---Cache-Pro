<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'WP_BITI_CORE_LIGHT_VERSION', '0.5.5' );
