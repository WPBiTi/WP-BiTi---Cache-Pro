<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class WP_BiTi_Core_Plugin_Page_Registry {
    private array $pages = array();

    public function register_page( array $page ): void {
        if ( empty( $page['slug'] ) || empty( $page['callback'] ) ) {
            return;
        }
        $this->pages[ $page['slug'] ] = $page;
    }

    public function all(): array {
        return $this->pages;
    }
}
