<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class WP_BiTi_Core_Capabilities {
    public static function ensure(): void {
        WP_BiTi_Cache_PRO_Permissions::ensure_caps();
    }
}
