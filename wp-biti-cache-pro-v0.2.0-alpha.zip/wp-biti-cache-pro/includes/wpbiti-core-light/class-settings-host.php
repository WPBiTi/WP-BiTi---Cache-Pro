<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class WP_BiTi_Core_Settings_Host {
    public static function render(): void {
        if ( ! current_user_can( 'wp_biti_manage' ) ) {
            wp_die( esc_html__( 'Access denied.', 'wp-biti-cache-pro' ) );
        }

        $registry = new WP_BiTi_Core_Settings_Tab_Registry();
        do_action( 'wp_biti_register_settings_tabs', $registry );
        $tabs = $registry->all();

        if ( empty( $tabs ) ) {
            echo '<div class="wrap wp-biti-core-wrap"><h1>' . esc_html__( 'WP BiTi Settings', 'wp-biti-cache-pro' ) . '</h1><p>' . esc_html__( 'No shared settings tabs are registered yet.', 'wp-biti-cache-pro' ) . '</p></div>';
            return;
        }

        $tab = filter_input( INPUT_GET, 'tab', FILTER_SANITIZE_FULL_SPECIAL_CHARS );
        $tab = is_string( $tab ) ? sanitize_key( wp_unslash( $tab ) ) : (string) key( $tabs );
        if ( ! isset( $tabs[ $tab ] ) ) {
            $tab = (string) key( $tabs );
        }
        ?>
        <div class="wrap wp-biti-core-wrap">
            <h1><?php echo esc_html__( 'WP BiTi Settings', 'wp-biti-cache-pro' ); ?></h1>
            <h2 class="nav-tab-wrapper">
                <?php foreach ( $tabs as $wpbiti_slug => $wpbiti_item ) : ?>
                    <?php $wpbiti_url = add_query_arg( array( 'page' => 'wp-biti-settings', 'tab' => $wpbiti_slug ), admin_url( 'admin.php' ) ); ?>
                    <a class="nav-tab <?php echo $wpbiti_slug === $tab ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( $wpbiti_url ); ?>"><?php echo esc_html( $wpbiti_item['title'] ); ?></a>
                <?php endforeach; ?>
            </h2>
            <div class="wp-biti-core-settings-host">
                <?php if ( isset( $tabs[ $tab ]['callback'] ) && is_callable( $tabs[ $tab ]['callback'] ) ) { call_user_func( $tabs[ $tab ]['callback'] ); } ?>
            </div>
        </div>
        <?php
    }
}
