<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class WP_BiTi_Core_Dashboard_Metaboxes {
    public static function boxes(): array {
        return apply_filters(
            'wp_biti_core_dashboard_boxes',
            array(
                'suite' => array(
                    'title'   => __( 'WP BiTi Suite', 'wp-biti-cache-pro' ),
                    'content' => __( 'Shared admin home for WP BiTi plugins. Each plugin keeps its own settings and logic while this menu keeps the suite organized.', 'wp-biti-cache-pro' ),
                ),
                'support' => array(
                    'title'   => __( 'Technical Support', 'wp-biti-cache-pro' ),
                    'content' => __( 'Use this area as the central dashboard for private and public WP BiTi plugins.', 'wp-biti-cache-pro' ),
                    'button'  => array( 'label' => __( 'Open wpbiti.com', 'wp-biti-cache-pro' ), 'url' => 'https://wpbiti.com' ),
                ),
                'author' => array(
                    'title'   => __( 'Author', 'wp-biti-cache-pro' ),
                    'content' => __( 'Created by Bogdan Tanasi with a focus on practical, readable and lightweight WordPress workflows.', 'wp-biti-cache-pro' ),
                ),
                'cache' => array(
                    'title'     => __( 'Current plugin', 'wp-biti-cache-pro' ),
                    'content'   => __( 'WP BiTi - Cache PRO is running with Core Light hosting the suite menu and page shell.', 'wp-biti-cache-pro' ),
                    'highlight' => true,
                ),
            )
        );
    }
}
