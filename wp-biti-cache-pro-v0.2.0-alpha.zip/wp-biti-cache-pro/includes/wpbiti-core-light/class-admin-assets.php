<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class WP_BiTi_Core_Admin_Assets {
    public static function init(): void {
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
    }

    public static function enqueue( string $hook ): void {
        if ( false === strpos( $hook, 'wp-biti' ) ) {
            return;
        }

        wp_enqueue_style( 'wp-biti-core-light', WP_BITI_CACHE_PRO_URL . 'assets/css/core-light.css', array(), WP_BITI_CORE_LIGHT_VERSION );
        wp_enqueue_script( 'wp-biti-core-light', WP_BITI_CACHE_PRO_URL . 'assets/js/core-light.js', array(), WP_BITI_CORE_LIGHT_VERSION, true );
    }
}
