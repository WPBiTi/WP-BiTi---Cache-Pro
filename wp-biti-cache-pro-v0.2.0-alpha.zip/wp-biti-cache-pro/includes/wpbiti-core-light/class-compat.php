<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class WP_BiTi_Core_Compat {
    public static function init(): void {
        // Reserved for future shared compatibility notices.
    }
}
