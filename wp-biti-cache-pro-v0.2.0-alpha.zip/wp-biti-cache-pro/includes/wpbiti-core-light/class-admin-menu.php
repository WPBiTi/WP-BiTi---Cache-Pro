<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class WP_BiTi_Core_Admin_Menu {
    public static function register(): void {
        add_menu_page(
            __( 'WP BiTi', 'wp-biti-cache-pro' ),
            __( 'WP BiTi', 'wp-biti-cache-pro' ),
            'wp_biti_access',
            'wp-biti',
            array( 'WP_BiTi_Core_Dashboard_Page', 'render' ),
            'dashicons-admin-generic',
            56
        );

        add_submenu_page(
            'wp-biti',
            __( 'Dashboard', 'wp-biti-cache-pro' ),
            __( 'Dashboard', 'wp-biti-cache-pro' ),
            'wp_biti_access',
            'wp-biti',
            array( 'WP_BiTi_Core_Dashboard_Page', 'render' )
        );

        $registry = new WP_BiTi_Core_Plugin_Page_Registry();
        do_action( 'wp_biti_register_plugin_pages', $registry );
        foreach ( $registry->all() as $page ) {
            add_submenu_page(
                'wp-biti',
                $page['title'],
                $page['menu_title'],
                $page['capability'],
                $page['slug'],
                $page['callback']
            );
        }

        add_submenu_page(
            'wp-biti',
            __( 'Settings', 'wp-biti-cache-pro' ),
            __( 'Settings', 'wp-biti-cache-pro' ),
            'wp_biti_manage',
            'wp-biti-settings',
            array( 'WP_BiTi_Core_Settings_Host', 'render' )
        );
    }
}
