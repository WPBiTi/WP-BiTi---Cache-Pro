<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once __DIR__ . '/version.php';
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/class-runtime-registry.php';
require_once __DIR__ . '/class-capabilities.php';
require_once __DIR__ . '/class-plugin-page-registry.php';
require_once __DIR__ . '/class-settings-tab-registry.php';
require_once __DIR__ . '/class-dashboard-metaboxes.php';
require_once __DIR__ . '/class-dashboard-page.php';
require_once __DIR__ . '/class-settings-host.php';
require_once __DIR__ . '/class-admin-menu.php';
require_once __DIR__ . '/class-admin-assets.php';
require_once __DIR__ . '/class-notices.php';
require_once __DIR__ . '/class-compat.php';
require_once __DIR__ . '/class-core-bootstrap.php';
