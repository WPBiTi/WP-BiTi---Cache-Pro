<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class WP_BiTi_Core_Notices {
    public static function init(): void {
        add_action( 'admin_notices', array( __CLASS__, 'render' ) );
    }

    public static function render(): void {
        if ( ! is_admin() ) {
            return;
        }

        $updated = filter_input( INPUT_GET, 'settings-updated', FILTER_SANITIZE_FULL_SPECIAL_CHARS );
        if ( ! is_string( $updated ) || '' === $updated ) {
            return;
        }

        $page = filter_input( INPUT_GET, 'page', FILTER_SANITIZE_FULL_SPECIAL_CHARS );
        $page = is_string( $page ) ? sanitize_key( wp_unslash( $page ) ) : '';
        if ( 0 !== strpos( $page, 'wp-biti' ) ) {
            return;
        }

        echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Settings saved.', 'wp-biti-cache-pro' ) . '</p></div>';
    }
}
