<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class WP_BiTi_Core_Bootstrap {
    public static function bootstrap(): void {
        if ( ! WP_BiTi_Core_Runtime_Registry::register( WP_BITI_CORE_LIGHT_VERSION ) ) {
            return;
        }

        WP_BiTi_Core_Capabilities::ensure();
        add_action( 'admin_menu', array( 'WP_BiTi_Core_Admin_Menu', 'register' ) );
        WP_BiTi_Core_Admin_Assets::init();
        WP_BiTi_Core_Notices::init();
        WP_BiTi_Core_Compat::init();
        do_action( 'wp_biti_core_loaded', WP_BITI_CORE_LIGHT_VERSION );
    }
}
