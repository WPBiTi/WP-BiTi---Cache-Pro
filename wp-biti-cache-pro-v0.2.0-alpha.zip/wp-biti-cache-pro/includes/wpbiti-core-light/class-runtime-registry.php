<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class WP_BiTi_Core_Runtime_Registry {
    private static string $version = '';
    private static bool $loaded = false;

    public static function register( string $version ): bool {
        if ( ! self::$loaded || version_compare( $version, self::$version, '>' ) ) {
            self::$version = $version;
            self::$loaded  = true;
            return true;
        }
        return false;
    }

    public static function get_version(): string {
        return self::$version;
    }

    public static function is_loaded(): bool {
        return self::$loaded;
    }
}
