<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class WP_BiTi_Cache_PRO_Admin_Bar {
    public static function init(): void {
        add_action( 'admin_bar_menu', array( __CLASS__, 'add_nodes' ), 100 );
    }

    public static function add_nodes( WP_Admin_Bar $admin_bar ): void {
        if ( ! WP_BiTi_Cache_PRO_Permissions::user_can_manage() ) {
            return;
        }

        $admin_bar->add_node(
            array(
                'id'    => 'wp-biti-cache',
                'title' => __( 'WP BiTi Cache', 'wp-biti-cache-pro' ),
                'href'  => admin_url( 'admin.php?page=' . WP_BITI_CACHE_PRO_SLUG ),
            )
        );

        $clear_url = wp_nonce_url(
            add_query_arg( array( 'action' => 'wp_biti_cache_clear_all' ), admin_url( 'admin-post.php' ) ),
            'wp_biti_cache_clear_all'
        );
        $admin_bar->add_node(
            array(
                'id'     => 'wp-biti-cache-clear-all',
                'parent' => 'wp-biti-cache',
                'title'  => __( 'Clear Cache', 'wp-biti-cache-pro' ),
                'href'   => $clear_url,
            )
        );

        $clear_minified_url = wp_nonce_url(
            add_query_arg( array( 'action' => 'wp_biti_cache_clear_all_and_minified' ), admin_url( 'admin-post.php' ) ),
            'wp_biti_cache_clear_all_and_minified'
        );
        $admin_bar->add_node(
            array(
                'id'     => 'wp-biti-cache-clear-minified',
                'parent' => 'wp-biti-cache',
                'title'  => __( 'Clear Cache and Minified CSS/JS', 'wp-biti-cache-pro' ),
                'href'   => $clear_minified_url,
            )
        );
    }
}
