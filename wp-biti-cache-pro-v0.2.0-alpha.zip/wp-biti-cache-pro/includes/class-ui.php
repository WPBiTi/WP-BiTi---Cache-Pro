<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class WP_BiTi_Cache_PRO_UI {
    public static function toggle( string $name, string $value, string $label, string $help = '' ): void {
        $field_id = sanitize_html_class( $name );
        ?>
        <div class="wp-biti-setting-row">
            <div class="wp-biti-setting-main">
                <label class="wp-biti-setting-label" for="<?php echo esc_attr( $field_id . '-on' ); ?>"><?php echo esc_html( $label ); ?></label>
                <?php if ( '' !== $help ) : ?>
                    <p class="description"><?php echo esc_html( $help ); ?></p>
                <?php endif; ?>
            </div>
            <div class="wp-biti-toggle" role="radiogroup" aria-label="<?php echo esc_attr( $label ); ?>">
                <input type="radio" id="<?php echo esc_attr( $field_id . '-off' ); ?>" name="<?php echo esc_attr( $name ); ?>" value="0" <?php checked( '0', $value ); ?> />
                <label for="<?php echo esc_attr( $field_id . '-off' ); ?>"><?php esc_html_e( 'OFF', 'wp-biti-cache-pro' ); ?></label>
                <input type="radio" id="<?php echo esc_attr( $field_id . '-on' ); ?>" name="<?php echo esc_attr( $name ); ?>" value="1" <?php checked( '1', $value ); ?> />
                <label for="<?php echo esc_attr( $field_id . '-on' ); ?>"><?php esc_html_e( 'ON', 'wp-biti-cache-pro' ); ?></label>
            </div>
        </div>
        <?php
    }

    public static function text( string $name, string $value, string $label, string $help = '', string $type = 'text', array $attrs = array() ): void {
        $field_id = sanitize_html_class( $name );
        ?>
        <div class="wp-biti-setting-row is-stack">
            <label class="wp-biti-setting-label" for="<?php echo esc_attr( $field_id ); ?>"><?php echo esc_html( $label ); ?></label>
            <input
                class="regular-text"
                type="<?php echo esc_attr( $type ); ?>"
                id="<?php echo esc_attr( $field_id ); ?>"
                name="<?php echo esc_attr( $name ); ?>"
                value="<?php echo esc_attr( $value ); ?>"
                <?php foreach ( $attrs as $attr_name => $attr_value ) : ?>
                    <?php echo esc_attr( $attr_name ); ?>="<?php echo esc_attr( (string) $attr_value ); ?>"
                <?php endforeach; ?>
            />
            <?php if ( '' !== $help ) : ?>
                <p class="description"><?php echo esc_html( $help ); ?></p>
            <?php endif; ?>
        </div>
        <?php
    }

    public static function textarea( string $name, string $value, string $label, string $help = '' ): void {
        $field_id = sanitize_html_class( $name );
        ?>
        <div class="wp-biti-setting-row is-stack">
            <label class="wp-biti-setting-label" for="<?php echo esc_attr( $field_id ); ?>"><?php echo esc_html( $label ); ?></label>
            <textarea class="large-text code" rows="6" id="<?php echo esc_attr( $field_id ); ?>" name="<?php echo esc_attr( $name ); ?>"><?php echo esc_textarea( $value ); ?></textarea>
            <?php if ( '' !== $help ) : ?>
                <p class="description"><?php echo esc_html( $help ); ?></p>
            <?php endif; ?>
        </div>
        <?php
    }

    public static function select( string $name, string $selected, array $options, string $label, string $help = '', array $attrs = array() ): void {
        $field_id = sanitize_html_class( $name );
        ?>
        <div class="wp-biti-setting-row is-stack">
            <label class="wp-biti-setting-label" for="<?php echo esc_attr( $field_id ); ?>"><?php echo esc_html( $label ); ?></label>
            <select id="<?php echo esc_attr( $field_id ); ?>" name="<?php echo esc_attr( $name ); ?>" <?php foreach ( $attrs as $attr_name => $attr_value ) : ?><?php echo esc_attr( $attr_name ); ?>="<?php echo esc_attr( (string) $attr_value ); ?>" <?php endforeach; ?>>
                <?php foreach ( $options as $option_value => $option_label ) : ?>
                    <option value="<?php echo esc_attr( (string) $option_value ); ?>" <?php selected( $selected, (string) $option_value ); ?>><?php echo esc_html( $option_label ); ?></option>
                <?php endforeach; ?>
            </select>
            <?php if ( '' !== $help ) : ?>
                <p class="description"><?php echo esc_html( $help ); ?></p>
            <?php endif; ?>
        </div>
        <?php
    }

    public static function stat_card( string $title, string $value, string $note = '' ): void {
        ?>
        <div class="wp-biti-stat-card">
            <h3><?php echo esc_html( $title ); ?></h3>
            <div class="wp-biti-stat-value"><?php echo esc_html( $value ); ?></div>
            <?php if ( '' !== $note ) : ?>
                <p><?php echo esc_html( $note ); ?></p>
            <?php endif; ?>
        </div>
        <?php
    }
}
