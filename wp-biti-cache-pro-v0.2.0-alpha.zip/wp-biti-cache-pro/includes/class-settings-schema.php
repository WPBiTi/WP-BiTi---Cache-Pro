<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class WP_BiTi_Cache_PRO_Settings_Schema {
    public static function defaults(): array {
        return array(
            'plugin_language_mode'          => 'wordpress',
            'plugin_language'               => 'en_US',
            'enable_cache'                  => '0',
            'cache_mobile'                  => '1',
            'cache_logged_in'               => '0',
            'cache_ttl_minutes'             => 1440,
            'auto_purge_on_new_content'     => '1',
            'auto_purge_on_update_content'  => '1',
            'enable_browser_cache'          => '1',
            'enable_gzip'                   => '0',
            'enable_preload'                => '0',
            'preload_method'                => 'default',
            'preload_homepage'              => '1',
            'preload_posts'                 => '1',
            'preload_pages'                 => '1',
            'preload_categories'            => '0',
            'preload_tags'                  => '0',
            'preload_public_cpts'           => '0',
            'preload_batch_size'            => 5,
            'preload_sitemap_url'           => '',
            'preload_restart_after_purge'   => '1',
            'minify_html'                   => '0',
            'advanced_html_optimization'    => '0',
            'minify_css'                    => '0',
            'advanced_css_optimization'     => '0',
            'combine_css'                   => '0',
            'minify_js'                     => '0',
            'combine_js'                    => '0',
            'footer_js_combine'             => '0',
            'lazy_load_media'               => '1',
            'disable_emojis'                => '1',
            'excluded_paths'                => '',
            'excluded_cookies'              => '',
            'excluded_user_agents'          => '',
        );
    }

    public static function fields_by_tab(): array {
        return array(
            'overview' => array(
                'plugin_language_mode',
                'plugin_language',
            ),
            'cache' => array(
                'enable_cache',
                'cache_mobile',
                'cache_logged_in',
                'cache_ttl_minutes',
                'auto_purge_on_new_content',
                'auto_purge_on_update_content',
                'enable_browser_cache',
                'enable_gzip',
            ),
            'preload' => array(
                'enable_preload',
                'preload_method',
                'preload_homepage',
                'preload_posts',
                'preload_pages',
                'preload_categories',
                'preload_tags',
                'preload_public_cpts',
                'preload_batch_size',
                'preload_sitemap_url',
                'preload_restart_after_purge',
            ),
            'optimization' => array(
                'minify_html',
                'advanced_html_optimization',
                'minify_css',
                'advanced_css_optimization',
                'combine_css',
                'minify_js',
                'combine_js',
                'footer_js_combine',
                'lazy_load_media',
                'disable_emojis',
            ),
            'exclusions' => array(
                'excluded_paths',
                'excluded_cookies',
                'excluded_user_agents',
            ),
        );
    }

    public static function sanitize_subset( string $tab, array $input, array $existing = array() ): array {
        $defaults   = self::defaults();
        $fields_map = self::fields_by_tab();
        $fields     = $fields_map[ $tab ] ?? array();
        $sanitized  = $existing;
        $input      = wp_unslash( $input );

        foreach ( $fields as $key ) {
            $default = $defaults[ $key ] ?? '';

            switch ( $key ) {
                case 'enable_cache':
                case 'cache_mobile':
                case 'cache_logged_in':
                case 'auto_purge_on_new_content':
                case 'auto_purge_on_update_content':
                case 'enable_browser_cache':
                case 'enable_gzip':
                case 'enable_preload':
                case 'preload_homepage':
                case 'preload_posts':
                case 'preload_pages':
                case 'preload_categories':
                case 'preload_tags':
                case 'preload_public_cpts':
                case 'preload_restart_after_purge':
                case 'minify_html':
                case 'advanced_html_optimization':
                case 'minify_css':
                case 'advanced_css_optimization':
                case 'combine_css':
                case 'minify_js':
                case 'combine_js':
                case 'footer_js_combine':
                case 'lazy_load_media':
                case 'disable_emojis':
                    $sanitized[ $key ] = ( isset( $input[ $key ] ) && '1' === (string) $input[ $key ] ) ? '1' : '0';
                    break;

                case 'cache_ttl_minutes':
                    $sanitized[ $key ] = max( 5, absint( $input[ $key ] ?? $default ) );
                    break;

                case 'preload_batch_size':
                    $sanitized[ $key ] = min( 20, max( 1, absint( $input[ $key ] ?? $default ) ) );
                    break;

                case 'preload_method':
                    $method            = sanitize_key( $input[ $key ] ?? $default );
                    $sanitized[ $key ] = in_array( $method, array( 'default', 'sitemap' ), true ) ? $method : 'default';
                    break;

                case 'preload_sitemap_url':
                    $sanitized[ $key ] = esc_url_raw( trim( (string) ( $input[ $key ] ?? '' ) ) );
                    break;

                case 'plugin_language_mode':
                    $mode              = sanitize_key( $input[ $key ] ?? $default );
                    $sanitized[ $key ] = in_array( $mode, array( 'wordpress', 'manual' ), true ) ? $mode : 'wordpress';
                    break;

                case 'plugin_language':
                    $locale = isset( $input[ $key ] ) ? sanitize_text_field( (string) $input[ $key ] ) : (string) ( $existing[ $key ] ?? $default );
                    $langs  = wp_biti_cache_get_available_languages();
                    $sanitized[ $key ] = isset( $langs[ $locale ] ) ? $locale : 'en_US';
                    break;

                case 'excluded_paths':
                case 'excluded_cookies':
                case 'excluded_user_agents':
                    $lines = wp_biti_cache_parse_multiline_list( (string) ( $input[ $key ] ?? '' ) );
                    $lines = array_map( 'sanitize_text_field', $lines );
                    $sanitized[ $key ] = implode( "\n", $lines );
                    break;

                default:
                    $sanitized[ $key ] = isset( $input[ $key ] ) ? sanitize_text_field( (string) $input[ $key ] ) : $default;
                    break;
            }
        }

        return wp_parse_args( $sanitized, $defaults );
    }
}
