<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class WP_BiTi_Cache_PRO_Preload_Manager {
    private const EVENT_HOOK = 'wp_biti_cache_preload_event';

    public static function init(): void {
        add_filter( 'cron_schedules', array( __CLASS__, 'add_schedule' ) );
        add_action( self::EVENT_HOOK, array( __CLASS__, 'run_batch' ) );
        add_action( 'admin_post_wp_biti_cache_preload_now', array( __CLASS__, 'handle_manual_start' ) );
    }

    public static function add_schedule( array $schedules ): array {
        $schedules['wp_biti_cache_five_minutes'] = array(
            'interval' => 5 * MINUTE_IN_SECONDS,
            'display'  => __( 'Every 5 minutes', 'wp-biti-cache-pro' ),
        );

        return $schedules;
    }

    public static function after_settings_save( array $old, array $new ): void {
        if ( '1' !== (string) $new['enable_preload'] ) {
            self::unschedule_all();
            update_option( WP_BITI_CACHE_PRO_PRELOAD_QUEUE_OPTION, array(), false );
            wp_biti_cache_update_state(
                array(
                    'preload_status'    => 'idle',
                    'preload_total'     => 0,
                    'preload_processed' => 0,
                )
            );

            return;
        }

        if ( wp_json_encode( $old ) !== wp_json_encode( $new ) ) {
            self::queue_urls( self::build_queue() );
            self::ensure_schedule();
            wp_schedule_single_event( time() + 15, self::EVENT_HOOK );
        }
    }

    public static function maybe_restart_after_purge(): void {
        if ( '1' !== (string) wp_biti_cache_get_setting( 'enable_preload', '0' ) ) {
            return;
        }

        if ( '1' !== (string) wp_biti_cache_get_setting( 'preload_restart_after_purge', '1' ) ) {
            return;
        }

        self::queue_urls( self::build_queue() );
        self::ensure_schedule();
        wp_schedule_single_event( time() + 30, self::EVENT_HOOK );
    }

    public static function handle_manual_start(): void {
        if ( ! WP_BiTi_Cache_PRO_Permissions::user_can_manage() ) {
            wp_die( esc_html__( 'Access denied.', 'wp-biti-cache-pro' ) );
        }

        check_admin_referer( 'wp_biti_cache_preload_now' );
        self::queue_urls( self::build_queue() );
        self::ensure_schedule();
        wp_schedule_single_event( time() + 10, self::EVENT_HOOK );

        $redirect = add_query_arg(
            array(
                'page'            => WP_BITI_CACHE_PRO_SLUG,
                'tab'             => 'preload',
                'preload-started' => '1',
            ),
            admin_url( 'admin.php' )
        );
        wp_safe_redirect( $redirect );
        exit;
    }

    public static function run_batch(): void {
        $queue = get_option( WP_BITI_CACHE_PRO_PRELOAD_QUEUE_OPTION, array() );
        if ( ! is_array( $queue ) || empty( $queue ) ) {
            wp_biti_cache_update_state(
                array(
                    'preload_status'    => 'completed',
                    'preload_last_run'  => time(),
                )
            );

            return;
        }

        $batch_size = (int) wp_biti_cache_get_setting( 'preload_batch_size', 5 );
        $processed  = 0;
        while ( $processed < $batch_size && ! empty( $queue ) ) {
            $url = array_shift( $queue );
            if ( is_string( $url ) && '' !== $url ) {
                wp_remote_get(
                    $url,
                    array(
                        'timeout'    => 10,
                        'user-agent' => 'WP BiTi Cache Preload/' . WP_BITI_CACHE_PRO_VERSION,
                    )
                );
                $processed++;
            }
        }

        update_option( WP_BITI_CACHE_PRO_PRELOAD_QUEUE_OPTION, array_values( $queue ), false );

        $state = wp_biti_cache_get_state();
        wp_biti_cache_update_state(
            array(
                'preload_status'    => empty( $queue ) ? 'completed' : 'running',
                'preload_total'     => max( (int) $state['preload_total'], $processed + (int) $state['preload_processed'] + count( $queue ) ),
                'preload_processed' => (int) $state['preload_processed'] + $processed,
                'preload_last_run'  => time(),
            )
        );
    }

    public static function build_queue(): array {
        $method = (string) wp_biti_cache_get_setting( 'preload_method', 'default' );
        $urls   = array();

        if ( 'sitemap' === $method ) {
            $urls = self::build_queue_from_sitemap();
        }

        if ( empty( $urls ) ) {
            $urls = self::build_queue_from_default();
        }

        return array_values( array_unique( array_filter( $urls, 'strlen' ) ) );
    }

    private static function build_queue_from_default(): array {
        $urls = array();

        if ( '1' === (string) wp_biti_cache_get_setting( 'preload_homepage', '1' ) ) {
            $urls[] = home_url( '/' );
        }

        $post_types = array();
        if ( '1' === (string) wp_biti_cache_get_setting( 'preload_posts', '1' ) ) {
            $post_types[] = 'post';
        }
        if ( '1' === (string) wp_biti_cache_get_setting( 'preload_pages', '1' ) ) {
            $post_types[] = 'page';
        }
        if ( '1' === (string) wp_biti_cache_get_setting( 'preload_public_cpts', '0' ) ) {
            $public_post_types = get_post_types( array( 'public' => true ), 'names' );
            foreach ( $public_post_types as $post_type_name ) {
                if ( ! in_array( $post_type_name, array( 'post', 'page', 'attachment' ), true ) ) {
                    $post_types[] = $post_type_name;
                }
            }
        }

        if ( ! empty( $post_types ) ) {
            $posts = get_posts(
                array(
                    'post_type'      => array_values( array_unique( $post_types ) ),
                    'post_status'    => 'publish',
                    'posts_per_page' => 200,
                    'orderby'        => 'date',
                    'order'          => 'DESC',
                    'fields'         => 'ids',
                )
            );
            foreach ( $posts as $post_id ) {
                $url = get_permalink( $post_id );
                if ( is_string( $url ) ) {
                    $urls[] = $url;
                }
            }
        }

        if ( '1' === (string) wp_biti_cache_get_setting( 'preload_categories', '0' ) ) {
            $terms = get_terms(
                array(
                    'taxonomy'   => 'category',
                    'hide_empty' => true,
                    'number'     => 100,
                )
            );
            if ( ! is_wp_error( $terms ) ) {
                foreach ( $terms as $term ) {
                    $url = get_term_link( $term );
                    if ( ! is_wp_error( $url ) ) {
                        $urls[] = $url;
                    }
                }
            }
        }

        if ( '1' === (string) wp_biti_cache_get_setting( 'preload_tags', '0' ) ) {
            $terms = get_terms(
                array(
                    'taxonomy'   => 'post_tag',
                    'hide_empty' => true,
                    'number'     => 100,
                )
            );
            if ( ! is_wp_error( $terms ) ) {
                foreach ( $terms as $term ) {
                    $url = get_term_link( $term );
                    if ( ! is_wp_error( $url ) ) {
                        $urls[] = $url;
                    }
                }
            }
        }

        return $urls;
    }

    private static function build_queue_from_sitemap(): array {
        $sitemap_url = (string) wp_biti_cache_get_setting( 'preload_sitemap_url', '' );
        if ( '' === $sitemap_url ) {
            $sitemap_url = home_url( '/wp-sitemap.xml' );
        }

        $response = wp_remote_get( $sitemap_url, array( 'timeout' => 10 ) );
        if ( is_wp_error( $response ) ) {
            return array();
        }

        $body = wp_remote_retrieve_body( $response );
        if ( '' === $body ) {
            return array();
        }

        $urls = array();
        libxml_use_internal_errors( true );
        $xml = simplexml_load_string( $body );
        if ( false === $xml ) {
            return array();
        }

        if ( isset( $xml->sitemap ) ) {
            foreach ( $xml->sitemap as $child ) {
                if ( isset( $child->loc ) ) {
                    $child_response = wp_remote_get( (string) $child->loc, array( 'timeout' => 10 ) );
                    if ( ! is_wp_error( $child_response ) ) {
                        $child_body = wp_remote_retrieve_body( $child_response );
                        $child_xml  = simplexml_load_string( $child_body );
                        if ( false !== $child_xml && isset( $child_xml->url ) ) {
                            foreach ( $child_xml->url as $url_node ) {
                                if ( isset( $url_node->loc ) ) {
                                    $urls[] = (string) $url_node->loc;
                                }
                            }
                        }
                    }
                }
            }
        } elseif ( isset( $xml->url ) ) {
            foreach ( $xml->url as $url_node ) {
                if ( isset( $url_node->loc ) ) {
                    $urls[] = (string) $url_node->loc;
                }
            }
        }

        return array_slice( array_values( array_unique( $urls ) ), 0, 500 );
    }

    private static function queue_urls( array $urls ): void {
        update_option( WP_BITI_CACHE_PRO_PRELOAD_QUEUE_OPTION, $urls, false );
        wp_biti_cache_update_state(
            array(
                'preload_status'    => empty( $urls ) ? 'idle' : 'queued',
                'preload_total'     => count( $urls ),
                'preload_processed' => 0,
            )
        );
    }

    private static function ensure_schedule(): void {
        if ( ! wp_next_scheduled( self::EVENT_HOOK ) ) {
            wp_schedule_event( time() + 60, 'wp_biti_cache_five_minutes', self::EVENT_HOOK );
        }
    }

    public static function unschedule_all(): void {
        $timestamp = wp_next_scheduled( self::EVENT_HOOK );
        while ( false !== $timestamp ) {
            wp_unschedule_event( $timestamp, self::EVENT_HOOK );
            $timestamp = wp_next_scheduled( self::EVENT_HOOK );
        }
    }
}
