<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class WP_BiTi_Cache_PRO_Plugin {
    private static bool $initialized = false;

    public static function init(): void {
        if ( self::$initialized ) {
            return;
        }

        self::$initialized = true;
        add_action( 'plugins_loaded', array( __CLASS__, 'bootstrap' ) );
    }

    public static function activate(): void {
        WP_BiTi_Cache_PRO_Permissions::ensure_caps();
        add_option( WP_BITI_CACHE_PRO_OPTION_KEY, WP_BiTi_Cache_PRO_Settings_Schema::defaults(), '', false );
        add_option( WP_BITI_CACHE_PRO_STATE_OPTION, wp_biti_cache_get_state(), '', false );
        add_option( WP_BITI_CACHE_PRO_DB_VERSION_OPTION, WP_BITI_CACHE_PRO_DB_VERSION, '', false );
        add_option( WP_BITI_CACHE_PRO_PRELOAD_QUEUE_OPTION, array(), '', false );
        WP_BiTi_Cache_PRO_Cache_Engine::ensure_cache_directories();
        flush_rewrite_rules();
    }

    public static function deactivate(): void {
        WP_BiTi_Cache_PRO_Preload_Manager::unschedule_all();
        flush_rewrite_rules();
    }

    public static function bootstrap(): void {
        WP_BiTi_Core_Bootstrap::bootstrap();
        WP_BiTi_Cache_PRO_I18n::init();
        WP_BiTi_Cache_PRO_Permissions::bootstrap();
        WP_BiTi_Cache_PRO_Settings_Controller::init();
        WP_BiTi_Cache_PRO_Admin_Assets::init();
        WP_BiTi_Cache_PRO_Admin_Page::init();
        WP_BiTi_Cache_PRO_Optimization::init();
        WP_BiTi_Cache_PRO_Cache_Engine::init();
        WP_BiTi_Cache_PRO_Preload_Manager::init();
        WP_BiTi_Cache_PRO_Database_Tools::init();
        WP_BiTi_Cache_PRO_Admin_Bar::init();
    }
}
