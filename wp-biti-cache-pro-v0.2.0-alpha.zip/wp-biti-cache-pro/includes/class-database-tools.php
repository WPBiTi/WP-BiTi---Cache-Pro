<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class WP_BiTi_Cache_PRO_Database_Tools {
    public static function init(): void {
        add_action( 'admin_post_wp_biti_cache_cleanup_database', array( __CLASS__, 'handle_cleanup' ) );
    }

    public static function handle_cleanup(): void {
        if ( ! WP_BiTi_Cache_PRO_Permissions::user_can_manage() ) {
            wp_die( esc_html__( 'Access denied.', 'wp-biti-cache-pro' ) );
        }

        check_admin_referer( 'wp_biti_cache_cleanup_database' );

        $deleted = array(
            'revisions'         => 0,
            'expired_transient' => 0,
            'trash_comments'    => 0,
            'spam_comments'     => 0,
        );

        $revisions = get_posts(
            array(
                'post_type'      => 'revision',
                'posts_per_page' => 500,
                'fields'         => 'ids',
            )
        );
        foreach ( $revisions as $revision_id ) {
            if ( wp_delete_post( $revision_id, true ) ) {
                $deleted['revisions']++;
            }
        }

        $option_keys = wp_load_alloptions();
        foreach ( array_keys( $option_keys ) as $option_name ) {
            if ( 0 !== strpos( (string) $option_name, '_transient_timeout_' ) ) {
                continue;
            }
            $timeout = (int) get_option( (string) $option_name );
            if ( $timeout > 0 && $timeout < time() ) {
                $transient = str_replace( '_transient_timeout_', '', (string) $option_name );
                delete_transient( $transient );
                $deleted['expired_transient']++;
            }
        }

        $trash_comments = get_comments(
            array(
                'status' => 'trash',
                'number' => 500,
                'fields' => 'ids',
            )
        );
        foreach ( $trash_comments as $comment_id ) {
            if ( wp_delete_comment( $comment_id, true ) ) {
                $deleted['trash_comments']++;
            }
        }

        $spam_comments = get_comments(
            array(
                'status' => 'spam',
                'number' => 500,
                'fields' => 'ids',
            )
        );
        foreach ( $spam_comments as $comment_id ) {
            if ( wp_delete_comment( $comment_id, true ) ) {
                $deleted['spam_comments']++;
            }
        }

        wp_biti_cache_update_state(
            array(
                'last_db_cleanup'     => time(),
                'last_db_cleanup_log' => $deleted,
            )
        );

        $redirect = add_query_arg(
            array(
                'page'             => WP_BITI_CACHE_PRO_SLUG,
                'tab'              => 'database',
                'database-cleaned' => '1',
            ),
            admin_url( 'admin.php' )
        );
        wp_safe_redirect( $redirect );
        exit;
    }
}
