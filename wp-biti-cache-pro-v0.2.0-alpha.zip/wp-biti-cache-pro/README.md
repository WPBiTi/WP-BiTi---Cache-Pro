# WP BiTi - Cache PRO

Private alpha plugin for the WP BiTi suite.

## Current scope
- Page cache on disk
- Preload queue
- HTML/CSS/JS optimization controls
- Exclusions
- Database cleanup
- Diagnostics tools
- Language mode selector

## Author
Bogdan Tanasi — https://wpbiti.com
