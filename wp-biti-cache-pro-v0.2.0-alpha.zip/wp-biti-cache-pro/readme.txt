=== WP BiTi - Cache PRO ===
Contributors: wpbiti
Requires at least: 6.1
Tested up to: 6.8
Requires PHP: 8.0
Stable tag: 0.2.0-alpha
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.html
Tags: cache, performance, optimization, preload, admin

Lightweight cache and optimization plugin for the WP BiTi suite.

== Description ==

WP BiTi - Cache PRO is a private alpha plugin by Bogdan Tanasi for the WP BiTi suite. It provides page caching, preload, exclusions, HTML/CSS/JS optimization, language handling, maintenance tools, and diagnostics inside one hosted page under the WP BiTi admin menu.

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/`.
2. Activate the plugin through the WordPress plugins screen.
3. Open `WP BiTi > WP BiTi Cache`.

== Changelog ==

= 0.2.0-alpha =
* Fixed the tab-safe settings save flow.
* Added clear cache and clear cache plus minified CSS/JS actions.
* Added CSS and JS optimization controls.
* Added language mode and manual language selection.
* Added project files for GitHub workflows.
