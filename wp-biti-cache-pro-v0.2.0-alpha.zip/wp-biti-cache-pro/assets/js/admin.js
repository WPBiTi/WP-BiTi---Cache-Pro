document.addEventListener('DOMContentLoaded', function () {
  var preloadSelect = document.querySelector('select[name="wp_biti_cache_settings[preload_method]"]');
  var defaultFields = document.querySelector('.wp-biti-preload-default-fields');
  var sitemapFields = document.querySelector('.wp-biti-preload-sitemap-fields');
  var languageModeSelect = document.querySelector('select[name="wp_biti_cache_settings[plugin_language_mode]"]');
  var languageField = document.querySelector('select[name="wp_biti_cache_settings[plugin_language]"]');

  function syncPreloadFields() {
    if (!preloadSelect || !defaultFields || !sitemapFields) {
      return;
    }
    var isSitemap = preloadSelect.value === 'sitemap';
    defaultFields.hidden = isSitemap;
    sitemapFields.hidden = !isSitemap;
  }

  function syncLanguageField() {
    if (!languageModeSelect || !languageField) {
      return;
    }
    languageField.disabled = languageModeSelect.value !== 'manual';
  }

  if (preloadSelect) {
    preloadSelect.addEventListener('change', syncPreloadFields);
    syncPreloadFields();
  }

  if (languageModeSelect) {
    languageModeSelect.addEventListener('change', syncLanguageField);
    syncLanguageField();
  }
});
