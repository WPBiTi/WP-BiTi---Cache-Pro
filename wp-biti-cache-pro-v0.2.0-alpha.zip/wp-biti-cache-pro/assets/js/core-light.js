document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('.wp-biti-core-box a.button').forEach(function (link) {
    link.setAttribute('rel', 'noreferrer noopener');
  });
});
