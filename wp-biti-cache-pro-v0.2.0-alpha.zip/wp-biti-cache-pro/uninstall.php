<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

delete_option( 'wp_biti_cache_settings' );
delete_option( 'wp_biti_cache_state' );
delete_option( 'wp_biti_cache_db_version' );
delete_option( 'wp_biti_cache_preload_queue' );
