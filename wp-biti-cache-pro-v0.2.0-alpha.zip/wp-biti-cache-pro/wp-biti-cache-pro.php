<?php
/**
 * Plugin Name: WP BiTi - Cache PRO
 * Plugin URI: https://wpbiti.com
 * Description: Lightweight page cache and optimization plugin for the WP BiTi suite, with one hosted admin page under WP BiTi.
 * Version: 0.2.0-alpha
 * Author: Bogdan Tanasi
 * Author URI: https://wpbiti.com
 * Text Domain: wp-biti-cache-pro
 * Domain Path: /languages
 * Requires at least: 6.1
 * Requires PHP: 8.0
 * License: GPL v3 or later
 * License URI: https://www.gnu.org/licenses/gpl-3.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'WP_BITI_CACHE_PRO_VERSION', '0.2.0-alpha' );
define( 'WP_BITI_CACHE_PRO_DB_VERSION', '0.2.0' );
define( 'WP_BITI_CACHE_PRO_PLUGIN_FILE', __FILE__ );
define( 'WP_BITI_CACHE_PRO_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
define( 'WP_BITI_CACHE_PRO_PATH', plugin_dir_path( __FILE__ ) );
define( 'WP_BITI_CACHE_PRO_URL', plugin_dir_url( __FILE__ ) );
define( 'WP_BITI_CACHE_PRO_SLUG', 'wp-biti-cache' );
define( 'WP_BITI_CACHE_PRO_TEXT_DOMAIN', 'wp-biti-cache-pro' );
define( 'WP_BITI_CACHE_PRO_DIST_CHANNEL', 'private-alpha' );
define( 'WP_BITI_CACHE_PRO_OPTION_KEY', 'wp_biti_cache_settings' );
define( 'WP_BITI_CACHE_PRO_DB_VERSION_OPTION', 'wp_biti_cache_db_version' );
define( 'WP_BITI_CACHE_PRO_STATE_OPTION', 'wp_biti_cache_state' );
define( 'WP_BITI_CACHE_PRO_PRELOAD_QUEUE_OPTION', 'wp_biti_cache_preload_queue' );
define( 'WP_BITI_CACHE_PRO_CACHE_DIR', WP_CONTENT_DIR . '/cache/wp-biti-cache/all/' );
define( 'WP_BITI_CACHE_PRO_MINIFIED_DIR', WP_CONTENT_DIR . '/cache/wp-biti-cache/minified/' );

require_once WP_BITI_CACHE_PRO_PATH . 'includes/wpbiti-core-light/bootstrap.php';
require_once WP_BITI_CACHE_PRO_PATH . 'includes/helpers.php';
require_once WP_BITI_CACHE_PRO_PATH . 'includes/class-permissions.php';
require_once WP_BITI_CACHE_PRO_PATH . 'includes/class-i18n.php';
require_once WP_BITI_CACHE_PRO_PATH . 'includes/class-settings-schema.php';
require_once WP_BITI_CACHE_PRO_PATH . 'includes/class-settings-controller.php';
require_once WP_BITI_CACHE_PRO_PATH . 'includes/class-admin-assets.php';
require_once WP_BITI_CACHE_PRO_PATH . 'includes/class-ui.php';
require_once WP_BITI_CACHE_PRO_PATH . 'includes/class-cache-engine.php';
require_once WP_BITI_CACHE_PRO_PATH . 'includes/class-preload-manager.php';
require_once WP_BITI_CACHE_PRO_PATH . 'includes/class-optimization.php';
require_once WP_BITI_CACHE_PRO_PATH . 'includes/class-database-tools.php';
require_once WP_BITI_CACHE_PRO_PATH . 'includes/class-admin-bar.php';
require_once WP_BITI_CACHE_PRO_PATH . 'includes/class-admin-page.php';
require_once WP_BITI_CACHE_PRO_PATH . 'includes/class-plugin.php';

register_activation_hook( __FILE__, array( 'WP_BiTi_Cache_PRO_Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'WP_BiTi_Cache_PRO_Plugin', 'deactivate' ) );

WP_BiTi_Cache_PRO_Plugin::init();
