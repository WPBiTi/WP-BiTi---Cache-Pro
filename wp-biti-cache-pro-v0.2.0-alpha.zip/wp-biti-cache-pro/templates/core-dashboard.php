<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>
<div class="wrap wp-biti-core-wrap">
    <h1><?php esc_html_e( 'WP BiTi', 'wp-biti-cache-pro' ); ?></h1>
    <p><?php esc_html_e( 'Shared lightweight dashboard for WP BiTi plugins. Use the submenu to open each plugin page.', 'wp-biti-cache-pro' ); ?></p>
    <div class="wp-biti-core-grid">
        <?php foreach ( $boxes as $wpbiti_box ) : ?>
            <section class="wp-biti-core-box <?php echo ! empty( $wpbiti_box['highlight'] ) ? 'is-highlight' : ''; ?>">
                <h2><?php echo esc_html( $wpbiti_box['title'] ); ?></h2>
                <p><?php echo esc_html( $wpbiti_box['content'] ); ?></p>
                <?php if ( ! empty( $wpbiti_box['button']['label'] ) && ! empty( $wpbiti_box['button']['url'] ) ) : ?>
                    <p><a class="button" href="<?php echo esc_url( $wpbiti_box['button']['url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $wpbiti_box['button']['label'] ); ?></a></p>
                <?php endif; ?>
            </section>
        <?php endforeach; ?>
    </div>
</div>
