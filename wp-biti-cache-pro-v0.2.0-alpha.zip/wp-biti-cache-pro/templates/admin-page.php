<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>
<div class="wrap wp-biti-cache-wrap">
    <h1><?php esc_html_e( 'WP BiTi Cache', 'wp-biti-cache-pro' ); ?></h1>
    <p class="wp-biti-page-intro"><?php esc_html_e( 'Single control center for cache, preload, optimization, exclusions and maintenance. This alpha build is designed for real testing with Plugin Check and live verification.', 'wp-biti-cache-pro' ); ?></p>

    <?php foreach ( $notices as $wpbiti_notice_message ) : ?>
        <div class="notice notice-success is-dismissible"><p><?php echo esc_html( $wpbiti_notice_message ); ?></p></div>
    <?php endforeach; ?>

    <nav class="nav-tab-wrapper wp-biti-tabs" aria-label="<?php esc_attr_e( 'WP BiTi Cache tabs', 'wp-biti-cache-pro' ); ?>">
        <?php foreach ( $tabs as $wpbiti_tab_slug => $wpbiti_tab_label ) : ?>
            <?php $wpbiti_tab_url = add_query_arg( array( 'page' => WP_BITI_CACHE_PRO_SLUG, 'tab' => $wpbiti_tab_slug ), admin_url( 'admin.php' ) ); ?>
            <a class="nav-tab <?php echo $tab === $wpbiti_tab_slug ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( $wpbiti_tab_url ); ?>"><?php echo esc_html( $wpbiti_tab_label ); ?></a>
        <?php endforeach; ?>
    </nav>

    <?php if ( 'overview' === $tab ) : ?>
        <div class="wp-biti-stats-grid">
            <?php WP_BiTi_Cache_PRO_UI::stat_card( __( 'Cache status', 'wp-biti-cache-pro' ), '1' === (string) $settings['enable_cache'] ? __( 'Enabled', 'wp-biti-cache-pro' ) : __( 'Disabled', 'wp-biti-cache-pro' ), __( 'Main page cache switch.', 'wp-biti-cache-pro' ) ); ?>
            <?php WP_BiTi_Cache_PRO_UI::stat_card( __( 'Last purge', 'wp-biti-cache-pro' ), wp_biti_cache_format_datetime( (int) $state['last_purge'] ), __( 'Updated when page cache is cleared.', 'wp-biti-cache-pro' ) ); ?>
            <?php
            $wpbiti_preload_note = sprintf(
                /* translators: 1: processed URL count, 2: total URL count. */
                __( '%1$d/%2$d URLs processed', 'wp-biti-cache-pro' ),
                (int) $state['preload_processed'],
                (int) $state['preload_total']
            );
            WP_BiTi_Cache_PRO_UI::stat_card( __( 'Preload status', 'wp-biti-cache-pro' ), ucfirst( (string) $state['preload_status'] ), $wpbiti_preload_note );
            ?>
            <?php WP_BiTi_Cache_PRO_UI::stat_card( __( 'Last minified cleanup', 'wp-biti-cache-pro' ), wp_biti_cache_format_datetime( (int) $state['last_minified_purge'] ), __( 'Updated when minified CSS/JS assets are cleared.', 'wp-biti-cache-pro' ) ); ?>
        </div>

        <div class="wp-biti-panel-grid">
            <section class="wp-biti-panel">
                <h2><?php esc_html_e( 'Quick actions', 'wp-biti-cache-pro' ); ?></h2>
                <p><?php esc_html_e( 'Use these actions while you test the alpha build on a real WordPress site.', 'wp-biti-cache-pro' ); ?></p>
                <div class="wp-biti-actions-row">
                    <a class="button button-primary" href="<?php echo esc_url( wp_nonce_url( add_query_arg( array( 'action' => 'wp_biti_cache_clear_all' ), admin_url( 'admin-post.php' ) ), 'wp_biti_cache_clear_all' ) ); ?>"><?php esc_html_e( 'Clear Cache', 'wp-biti-cache-pro' ); ?></a>
                    <a class="button" href="<?php echo esc_url( wp_nonce_url( add_query_arg( array( 'action' => 'wp_biti_cache_clear_all_and_minified' ), admin_url( 'admin-post.php' ) ), 'wp_biti_cache_clear_all_and_minified' ) ); ?>"><?php esc_html_e( 'Clear Cache and Minified CSS/JS', 'wp-biti-cache-pro' ); ?></a>
                    <a class="button" href="<?php echo esc_url( wp_nonce_url( add_query_arg( array( 'action' => 'wp_biti_cache_preload_now' ), admin_url( 'admin-post.php' ) ), 'wp_biti_cache_preload_now' ) ); ?>"><?php esc_html_e( 'Start preload now', 'wp-biti-cache-pro' ); ?></a>
                </div>
            </section>
            <section class="wp-biti-panel">
                <h2><?php esc_html_e( 'Scope in this build', 'wp-biti-cache-pro' ); ?></h2>
                <ul class="wp-biti-check-list">
                    <li><?php esc_html_e( 'Disk page cache for public HTML pages', 'wp-biti-cache-pro' ); ?></li>
                    <li><?php esc_html_e( 'Preload queue with Default and Sitemap methods', 'wp-biti-cache-pro' ); ?></li>
                    <li><?php esc_html_e( 'Automatic purge on new or updated published content', 'wp-biti-cache-pro' ); ?></li>
                    <li><?php esc_html_e( 'HTML, CSS and JS optimization options with minified asset cleanup', 'wp-biti-cache-pro' ); ?></li>
                    <li><?php esc_html_e( 'Exclusions, database cleanup and diagnostics tools', 'wp-biti-cache-pro' ); ?></li>
                </ul>
            </section>
        </div>

        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="wp-biti-settings-form">
            <input type="hidden" name="action" value="wp_biti_cache_save_settings" />
            <input type="hidden" name="current_tab" value="overview" />
            <?php wp_nonce_field( 'wp_biti_cache_save_settings' ); ?>
            <div class="wp-biti-panel">
                <h2><?php esc_html_e( 'Plugin Language', 'wp-biti-cache-pro' ); ?></h2>
                <?php
                WP_BiTi_Cache_PRO_UI::select(
                    'wp_biti_cache_settings[plugin_language_mode]',
                    (string) $settings['plugin_language_mode'],
                    array(
                        'wordpress' => __( 'Use WordPress default', 'wp-biti-cache-pro' ),
                        'manual'    => __( 'Manual selection', 'wp-biti-cache-pro' ),
                    ),
                    __( 'Plugin language mode', 'wp-biti-cache-pro' ),
                    __( 'By default, the plugin follows the current WordPress locale.', 'wp-biti-cache-pro' )
                );
                WP_BiTi_Cache_PRO_UI::select(
                    'wp_biti_cache_settings[plugin_language]',
                    (string) $settings['plugin_language'],
                    wp_biti_cache_get_available_languages(),
                    __( 'Plugin language', 'wp-biti-cache-pro' ),
                    __( 'This manual selection is used only when the mode is set to manual.', 'wp-biti-cache-pro' )
                );
                ?>
                <div class="wp-biti-info-strip">
                    <strong><?php esc_html_e( 'Current effective language:', 'wp-biti-cache-pro' ); ?></strong>
                    <?php echo esc_html( wp_biti_cache_get_effective_language_label() ); ?>
                    <span class="wp-biti-muted">(<?php echo esc_html( wp_biti_cache_get_effective_locale() ); ?>)</span>
                </div>
                <p class="submit"><button type="submit" class="button button-primary"><?php esc_html_e( 'Save settings', 'wp-biti-cache-pro' ); ?></button></p>
            </div>
        </form>
    <?php else : ?>
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="wp-biti-settings-form">
            <input type="hidden" name="action" value="wp_biti_cache_save_settings" />
            <input type="hidden" name="current_tab" value="<?php echo esc_attr( $tab ); ?>" />
            <?php wp_nonce_field( 'wp_biti_cache_save_settings' ); ?>

            <div class="wp-biti-panel">
                <?php if ( 'cache' === $tab ) : ?>
                    <h2><?php esc_html_e( 'Cache engine', 'wp-biti-cache-pro' ); ?></h2>
                    <?php WP_BiTi_Cache_PRO_UI::toggle( 'wp_biti_cache_settings[enable_cache]', (string) $settings['enable_cache'], __( 'Enable page cache', 'wp-biti-cache-pro' ), __( 'Stores public HTML pages as static cache files on disk.', 'wp-biti-cache-pro' ) ); ?>
                    <?php WP_BiTi_Cache_PRO_UI::toggle( 'wp_biti_cache_settings[cache_mobile]', (string) $settings['cache_mobile'], __( 'Cache for mobile devices', 'wp-biti-cache-pro' ), __( 'Creates a dedicated cache key for mobile requests.', 'wp-biti-cache-pro' ) ); ?>
                    <?php WP_BiTi_Cache_PRO_UI::toggle( 'wp_biti_cache_settings[cache_logged_in]', (string) $settings['cache_logged_in'], __( 'Cache for logged-in users', 'wp-biti-cache-pro' ), __( 'Keep this OFF on most sites. Logged-in pages are usually dynamic.', 'wp-biti-cache-pro' ) ); ?>
                    <?php WP_BiTi_Cache_PRO_UI::text( 'wp_biti_cache_settings[cache_ttl_minutes]', (string) $settings['cache_ttl_minutes'], __( 'Cache TTL in minutes', 'wp-biti-cache-pro' ), __( 'How long a cache file remains fresh before it is regenerated.', 'wp-biti-cache-pro' ), 'number', array( 'min' => 5, 'step' => 5 ) ); ?>
                    <?php WP_BiTi_Cache_PRO_UI::toggle( 'wp_biti_cache_settings[auto_purge_on_new_content]', (string) $settings['auto_purge_on_new_content'], __( 'Auto purge on new content', 'wp-biti-cache-pro' ), __( 'Clears cache when a new published post or page is created.', 'wp-biti-cache-pro' ) ); ?>
                    <?php WP_BiTi_Cache_PRO_UI::toggle( 'wp_biti_cache_settings[auto_purge_on_update_content]', (string) $settings['auto_purge_on_update_content'], __( 'Auto purge on updated content', 'wp-biti-cache-pro' ), __( 'Clears cache when a published post or page is updated.', 'wp-biti-cache-pro' ) ); ?>
                    <?php WP_BiTi_Cache_PRO_UI::toggle( 'wp_biti_cache_settings[enable_browser_cache]', (string) $settings['enable_browser_cache'], __( 'Browser cache headers', 'wp-biti-cache-pro' ), __( 'Sends Cache-Control headers on cached page responses.', 'wp-biti-cache-pro' ) ); ?>
                    <?php WP_BiTi_Cache_PRO_UI::toggle( 'wp_biti_cache_settings[enable_gzip]', (string) $settings['enable_gzip'], __( 'Gzip delivery', 'wp-biti-cache-pro' ), __( 'Compresses cache output when the visitor browser supports gzip.', 'wp-biti-cache-pro' ) ); ?>
                <?php elseif ( 'preload' === $tab ) : ?>
                    <h2><?php esc_html_e( 'Preload', 'wp-biti-cache-pro' ); ?></h2>
                    <?php WP_BiTi_Cache_PRO_UI::toggle( 'wp_biti_cache_settings[enable_preload]', (string) $settings['enable_preload'], __( 'Enable preload', 'wp-biti-cache-pro' ), __( 'Builds a queue and warms cache files in the background.', 'wp-biti-cache-pro' ) ); ?>
                    <?php WP_BiTi_Cache_PRO_UI::select( 'wp_biti_cache_settings[preload_method]', (string) $settings['preload_method'], array( 'default' => __( 'Default (newest content first)', 'wp-biti-cache-pro' ), 'sitemap' => __( 'Sitemap', 'wp-biti-cache-pro' ) ), __( 'Preload method', 'wp-biti-cache-pro' ), __( 'Default uses WordPress content. Sitemap reads URLs from an XML sitemap.', 'wp-biti-cache-pro' ) ); ?>
                    <div class="wp-biti-preload-default-fields" <?php echo 'sitemap' === (string) $settings['preload_method'] ? 'hidden' : ''; ?>>
                        <?php WP_BiTi_Cache_PRO_UI::toggle( 'wp_biti_cache_settings[preload_homepage]', (string) $settings['preload_homepage'], __( 'Include homepage', 'wp-biti-cache-pro' ) ); ?>
                        <?php WP_BiTi_Cache_PRO_UI::toggle( 'wp_biti_cache_settings[preload_posts]', (string) $settings['preload_posts'], __( 'Include posts', 'wp-biti-cache-pro' ) ); ?>
                        <?php WP_BiTi_Cache_PRO_UI::toggle( 'wp_biti_cache_settings[preload_pages]', (string) $settings['preload_pages'], __( 'Include pages', 'wp-biti-cache-pro' ) ); ?>
                        <?php WP_BiTi_Cache_PRO_UI::toggle( 'wp_biti_cache_settings[preload_categories]', (string) $settings['preload_categories'], __( 'Include categories', 'wp-biti-cache-pro' ) ); ?>
                        <?php WP_BiTi_Cache_PRO_UI::toggle( 'wp_biti_cache_settings[preload_tags]', (string) $settings['preload_tags'], __( 'Include tags', 'wp-biti-cache-pro' ) ); ?>
                        <?php WP_BiTi_Cache_PRO_UI::toggle( 'wp_biti_cache_settings[preload_public_cpts]', (string) $settings['preload_public_cpts'], __( 'Include public CPTs', 'wp-biti-cache-pro' ) ); ?>
                    </div>
                    <div class="wp-biti-preload-sitemap-fields" <?php echo 'sitemap' === (string) $settings['preload_method'] ? '' : 'hidden'; ?>>
                        <?php WP_BiTi_Cache_PRO_UI::text( 'wp_biti_cache_settings[preload_sitemap_url]', (string) $settings['preload_sitemap_url'], __( 'Sitemap URL', 'wp-biti-cache-pro' ), __( 'Leave empty to use /wp-sitemap.xml.', 'wp-biti-cache-pro' ), 'url' ); ?>
                    </div>
                    <?php WP_BiTi_Cache_PRO_UI::text( 'wp_biti_cache_settings[preload_batch_size]', (string) $settings['preload_batch_size'], __( 'URLs per cycle', 'wp-biti-cache-pro' ), __( 'Recommended range for the alpha: 3 to 10.', 'wp-biti-cache-pro' ), 'number', array( 'min' => 1, 'max' => 20 ) ); ?>
                    <?php WP_BiTi_Cache_PRO_UI::toggle( 'wp_biti_cache_settings[preload_restart_after_purge]', (string) $settings['preload_restart_after_purge'], __( 'Restart after full purge', 'wp-biti-cache-pro' ), __( 'When cache is cleared, queue the preload again automatically.', 'wp-biti-cache-pro' ) ); ?>
                    <div class="wp-biti-info-strip">
                        <strong><?php esc_html_e( 'Current status:', 'wp-biti-cache-pro' ); ?></strong>
                        <?php echo esc_html( ucfirst( (string) $state['preload_status'] ) ); ?> —
                        <?php
                        echo esc_html(
                            sprintf(
                                /* translators: 1: processed URL count, 2: total URL count. */
                                __( '%1$d/%2$d URLs processed', 'wp-biti-cache-pro' ),
                                (int) $state['preload_processed'],
                                (int) $state['preload_total']
                            )
                        );
                        ?>
                    </div>
                <?php elseif ( 'optimization' === $tab ) : ?>
                    <h2><?php esc_html_e( 'Optimization', 'wp-biti-cache-pro' ); ?></h2>
                    <?php WP_BiTi_Cache_PRO_UI::toggle( 'wp_biti_cache_settings[minify_html]', (string) $settings['minify_html'], __( 'Minify HTML', 'wp-biti-cache-pro' ), __( 'Applies conservative HTML minification before writing cache files.', 'wp-biti-cache-pro' ) ); ?>
                    <?php WP_BiTi_Cache_PRO_UI::toggle( 'wp_biti_cache_settings[advanced_html_optimization]', (string) $settings['advanced_html_optimization'], __( 'Advanced HTML Optimization', 'wp-biti-cache-pro' ), __( 'Adds stronger HTML cleanup, removes comments, and minifies inline CSS/JS more aggressively.', 'wp-biti-cache-pro' ) ); ?>
                    <?php WP_BiTi_Cache_PRO_UI::toggle( 'wp_biti_cache_settings[minify_css]', (string) $settings['minify_css'], __( 'Minify CSS', 'wp-biti-cache-pro' ), __( 'Minifies local stylesheet files and serves optimized copies from the cache folder.', 'wp-biti-cache-pro' ) ); ?>
                    <?php WP_BiTi_Cache_PRO_UI::toggle( 'wp_biti_cache_settings[advanced_css_optimization]', (string) $settings['advanced_css_optimization'], __( 'Advanced CSS Optimization', 'wp-biti-cache-pro' ), __( 'Applies a stronger CSS minification pass to local assets.', 'wp-biti-cache-pro' ) ); ?>
                    <?php WP_BiTi_Cache_PRO_UI::toggle( 'wp_biti_cache_settings[combine_css]', (string) $settings['combine_css'], __( 'Combine CSS', 'wp-biti-cache-pro' ), __( 'Combines eligible local stylesheets loaded in the document head.', 'wp-biti-cache-pro' ) ); ?>
                    <?php WP_BiTi_Cache_PRO_UI::toggle( 'wp_biti_cache_settings[minify_js]', (string) $settings['minify_js'], __( 'Minify JS', 'wp-biti-cache-pro' ), __( 'Minifies eligible local JavaScript files.', 'wp-biti-cache-pro' ) ); ?>
                    <?php WP_BiTi_Cache_PRO_UI::toggle( 'wp_biti_cache_settings[combine_js]', (string) $settings['combine_js'], __( 'Combine JS', 'wp-biti-cache-pro' ), __( 'Combines eligible local JavaScript files placed in the head section.', 'wp-biti-cache-pro' ) ); ?>
                    <?php WP_BiTi_Cache_PRO_UI::toggle( 'wp_biti_cache_settings[footer_js_combine]', (string) $settings['footer_js_combine'], __( 'Footer JS Combine', 'wp-biti-cache-pro' ), __( 'Combines eligible local JavaScript files loaded in the footer.', 'wp-biti-cache-pro' ) ); ?>
                    <?php WP_BiTi_Cache_PRO_UI::toggle( 'wp_biti_cache_settings[lazy_load_media]', (string) $settings['lazy_load_media'], __( 'Lazy-load images and iframes', 'wp-biti-cache-pro' ), __( 'Adds loading="lazy" on markup generated by WordPress content filters.', 'wp-biti-cache-pro' ) ); ?>
                    <?php WP_BiTi_Cache_PRO_UI::toggle( 'wp_biti_cache_settings[disable_emojis]', (string) $settings['disable_emojis'], __( 'Disable WordPress emojis', 'wp-biti-cache-pro' ), __( 'Removes the default emoji scripts and styles from WordPress output.', 'wp-biti-cache-pro' ) ); ?>
                <?php elseif ( 'exclusions' === $tab ) : ?>
                    <h2><?php esc_html_e( 'Exclusions', 'wp-biti-cache-pro' ); ?></h2>
                    <?php WP_BiTi_Cache_PRO_UI::textarea( 'wp_biti_cache_settings[excluded_paths]', (string) $settings['excluded_paths'], __( 'Excluded URL paths', 'wp-biti-cache-pro' ), __( 'One value per line. Example: /cart or /my-account', 'wp-biti-cache-pro' ) ); ?>
                    <?php WP_BiTi_Cache_PRO_UI::textarea( 'wp_biti_cache_settings[excluded_cookies]', (string) $settings['excluded_cookies'], __( 'Excluded cookies', 'wp-biti-cache-pro' ), __( 'If one of these cookies exists, the request will bypass cache.', 'wp-biti-cache-pro' ) ); ?>
                    <?php WP_BiTi_Cache_PRO_UI::textarea( 'wp_biti_cache_settings[excluded_user_agents]', (string) $settings['excluded_user_agents'], __( 'Excluded user agents', 'wp-biti-cache-pro' ), __( 'Case-insensitive contains match, one value per line.', 'wp-biti-cache-pro' ) ); ?>
                <?php elseif ( 'database' === $tab ) : ?>
                    <h2><?php esc_html_e( 'Database cleanup', 'wp-biti-cache-pro' ); ?></h2>
                    <p><?php esc_html_e( 'This alpha build can remove revisions, expired transients, trashed comments and spam comments.', 'wp-biti-cache-pro' ); ?></p>
                    <div class="wp-biti-info-strip">
                        <strong><?php esc_html_e( 'Last cleanup:', 'wp-biti-cache-pro' ); ?></strong>
                        <?php echo esc_html( wp_biti_cache_format_datetime( (int) $state['last_db_cleanup'] ) ); ?>
                    </div>
                    <?php if ( ! empty( $state['last_db_cleanup_log'] ) && is_array( $state['last_db_cleanup_log'] ) ) : ?>
                        <ul class="wp-biti-check-list">
                            <?php foreach ( $state['last_db_cleanup_log'] as $wpbiti_cleanup_label => $wpbiti_cleanup_count ) : ?>
                                <li><?php echo esc_html( sprintf( '%s: %d', ucwords( str_replace( '_', ' ', (string) $wpbiti_cleanup_label ) ), (int) $wpbiti_cleanup_count ) ); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                    <p>
                        <a class="button button-secondary" href="<?php echo esc_url( wp_nonce_url( add_query_arg( array( 'action' => 'wp_biti_cache_cleanup_database' ), admin_url( 'admin-post.php' ) ), 'wp_biti_cache_cleanup_database' ) ); ?>"><?php esc_html_e( 'Run cleanup now', 'wp-biti-cache-pro' ); ?></a>
                    </p>
                <?php elseif ( 'tools' === $tab ) : ?>
                    <h2><?php esc_html_e( 'Tools and diagnostics', 'wp-biti-cache-pro' ); ?></h2>
                    <div class="wp-biti-actions-row">
                        <a class="button button-primary" href="<?php echo esc_url( wp_nonce_url( add_query_arg( array( 'action' => 'wp_biti_cache_clear_all' ), admin_url( 'admin-post.php' ) ), 'wp_biti_cache_clear_all' ) ); ?>"><?php esc_html_e( 'Clear Cache', 'wp-biti-cache-pro' ); ?></a>
                        <a class="button" href="<?php echo esc_url( wp_nonce_url( add_query_arg( array( 'action' => 'wp_biti_cache_clear_all_and_minified' ), admin_url( 'admin-post.php' ) ), 'wp_biti_cache_clear_all_and_minified' ) ); ?>"><?php esc_html_e( 'Clear Cache and Minified CSS/JS', 'wp-biti-cache-pro' ); ?></a>
                        <a class="button" href="<?php echo esc_url( wp_nonce_url( add_query_arg( array( 'action' => 'wp_biti_cache_preload_now' ), admin_url( 'admin-post.php' ) ), 'wp_biti_cache_preload_now' ) ); ?>"><?php esc_html_e( 'Start preload now', 'wp-biti-cache-pro' ); ?></a>
                        <a class="button" href="<?php echo esc_url( wp_nonce_url( add_query_arg( array( 'action' => 'wp_biti_cache_regenerate_rules' ), admin_url( 'admin-post.php' ) ), 'wp_biti_cache_regenerate_rules' ) ); ?>"><?php esc_html_e( 'Regenerate rules', 'wp-biti-cache-pro' ); ?></a>
                    </div>
                    <table class="widefat striped wp-biti-system-table">
                        <tbody>
                            <tr><td><?php esc_html_e( 'Plugin version', 'wp-biti-cache-pro' ); ?></td><td><?php echo esc_html( WP_BITI_CACHE_PRO_VERSION ); ?></td></tr>
                            <tr><td><?php esc_html_e( 'Core Light version', 'wp-biti-cache-pro' ); ?></td><td><?php echo esc_html( wp_biti_core_version() ); ?></td></tr>
                            <tr><td><?php esc_html_e( 'Cache directory', 'wp-biti-cache-pro' ); ?></td><td><code><?php echo esc_html( WP_BITI_CACHE_PRO_CACHE_DIR ); ?></code></td></tr>
                            <tr><td><?php esc_html_e( 'Minified directory', 'wp-biti-cache-pro' ); ?></td><td><code><?php echo esc_html( WP_BITI_CACHE_PRO_MINIFIED_DIR ); ?></code></td></tr>
                            <tr><td><?php esc_html_e( 'Cache directory writable', 'wp-biti-cache-pro' ); ?></td><td><?php echo esc_html( wp_is_writable( WP_CONTENT_DIR . '/cache' ) ? __( 'Yes', 'wp-biti-cache-pro' ) : __( 'No', 'wp-biti-cache-pro' ) ); ?></td></tr>
                            <tr><td><?php esc_html_e( 'PHP version', 'wp-biti-cache-pro' ); ?></td><td><?php echo esc_html( PHP_VERSION ); ?></td></tr>
                            <tr><td><?php esc_html_e( 'WordPress version', 'wp-biti-cache-pro' ); ?></td><td><?php echo esc_html( get_bloginfo( 'version' ) ); ?></td></tr>
                            <tr><td><?php esc_html_e( 'Gzip extension available', 'wp-biti-cache-pro' ); ?></td><td><?php echo esc_html( function_exists( 'gzencode' ) ? __( 'Yes', 'wp-biti-cache-pro' ) : __( 'No', 'wp-biti-cache-pro' ) ); ?></td></tr>
                            <tr><td><?php esc_html_e( 'Effective plugin language', 'wp-biti-cache-pro' ); ?></td><td><?php echo esc_html( wp_biti_cache_get_effective_language_label() . ' (' . wp_biti_cache_get_effective_locale() . ')' ); ?></td></tr>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <?php if ( in_array( $tab, array( 'cache', 'preload', 'optimization', 'exclusions' ), true ) ) : ?>
                <p class="submit"><button type="submit" class="button button-primary"><?php esc_html_e( 'Save settings', 'wp-biti-cache-pro' ); ?></button></p>
            <?php endif; ?>
        </form>
    <?php endif; ?>
</div>
